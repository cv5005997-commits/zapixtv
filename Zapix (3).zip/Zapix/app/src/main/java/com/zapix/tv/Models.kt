package com.zapix.tv

const val NO_GROUP = "Sin grupo"

data class Channel(
    val number: Int,
    val name: String,
    val group: String,
    val url: String,
    val logo: String,
    val epgId: String, // en minúsculas; vacío si el canal no tiene guía
    val ua: String = "",       // User-Agent propio del canal (si la lista lo indica)
    val referer: String = ""   // Referer propio del canal (si la lista lo indica)
)

data class Program(val start: Long, val stop: Long, val title: String, val desc: String)

/** Una lista del usuario. M3U: a = URL. Xtream: a = servidor, b = usuario, c = contraseña. Stalker: a = portal, b = MAC. */
data class Source(
    val id: String,
    val type: Int,
    val name: String,
    val a: String,
    val b: String,
    val c: String
) {
    companion object {
        const val M3U = 0
        const val XTREAM = 1
        const val STALKER = 2
    }
}
