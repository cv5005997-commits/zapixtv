package com.zapix.tv

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

private const val WHITE = 0xFFFFFFFF.toInt()
private const val BLUE = 0xFF5AA2FF.toInt()

/** Lista simple de canales (Inicio y Buscar). Marca en azul el canal que se está reproduciendo. */
class ChannelListAdapter(
    private val inflater: LayoutInflater,
    private val logos: LogoLoader,
    private val settings: Settings
) : BaseAdapter() {

    var items: List<Channel> = emptyList()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    var playingUrl: String? = null
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun getCount() = items.size
    override fun getItem(position: Int): Any = items[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val row = convertView ?: inflater.inflate(R.layout.row_channel, parent, false)
        val c = items[position]
        val f = settings.textFactor()
        val logo = row.findViewById<ImageView>(R.id.rcLogo)
        val name = row.findViewById<TextView>(R.id.rcName)
        val group = row.findViewById<TextView>(R.id.rcGroup)
        name.text = c.name
        name.textSize = 20f * f
        name.setTextColor(if (c.url == playingUrl) BLUE else WHITE)
        group.text = c.group
        group.textSize = 13f * f
        if (settings.showLogos) {
            logo.visibility = View.VISIBLE
            logos.load(c.logo, logo)
        } else {
            logo.visibility = View.GONE
        }
        return row
    }
}

/** Lista de grupos de la pestaña TV. */
class GroupAdapter(context: Context) :
    ArrayAdapter<String>(context, android.R.layout.simple_list_item_1) {

    var factor = 1f
    var selected = -1

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val v = super.getView(position, convertView, parent) as TextView
        v.textSize = 20f * factor
        v.setTextColor(if (position == selected) BLUE else WHITE)
        return v
    }
}

/** Filas de la guía: número, logo, nombre y los programas del canal. */
class EpgRowAdapter(
    private val inflater: LayoutInflater,
    private val logos: LogoLoader,
    private val settings: Settings,
    private val win: EpgWindow,
    private val programsFor: (Channel) -> List<Program>
) : BaseAdapter() {

    var items: List<Channel> = emptyList()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    var playingUrl: String? = null
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    var selRow = -1
    var selProg = -1

    override fun getCount() = items.size
    override fun getItem(position: Int): Any = items[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val row = convertView ?: inflater.inflate(R.layout.row_epg, parent, false)
        val c = items[position]
        val f = settings.textFactor()

        val number = row.findViewById<TextView>(R.id.rowNumber)
        val logo = row.findViewById<ImageView>(R.id.rowLogo)
        val name = row.findViewById<TextView>(R.id.rowName)
        val strip = row.findViewById<EpgStripView>(R.id.rowStrip)

        if (settings.showNumbers) {
            number.visibility = View.VISIBLE
            number.text = c.number.toString()
            number.textSize = 18f * f
        } else {
            number.visibility = View.GONE
        }
        if (settings.showLogos) {
            logo.visibility = View.VISIBLE
            logos.load(c.logo, logo)
        } else {
            logo.visibility = View.GONE
        }
        name.text = c.name
        name.textSize = 18f * f
        name.setTextColor(if (c.url == playingUrl) BLUE else WHITE)

        strip.windowStart = win.startMs
        strip.windowMinutes = win.minutes
        strip.nowMs = System.currentTimeMillis()
        strip.textFactor = f
        strip.programs = programsFor(c)
        strip.selected = if (position == selRow) selProg else -1
        strip.invalidate()
        return row
    }
}
