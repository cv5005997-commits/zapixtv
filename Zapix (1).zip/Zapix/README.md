# Zapix

Reproductor de listas para Android TV y celular, parecido a TiviMate pero liviano y con todos los ajustes gratis.
Pensado para una TV de 32" con 1 GB de RAM. Listas M3U, Xtream Codes y Portal Stalker (sin grabador).

## Compilar el APK (GitHub Actions)

1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta (incluida `.github`).
2. En la pestaña **Actions** espera a que termine "Compilar APK".
3. Descarga el artefacto **Zapix-apk**: dentro está `app-release.apk`.
4. Instálalo en la TV (USB, "Send Files to TV" o `adb install app-release.apk`).

## Pantallas (barra lateral)

- **Buscar:** busca canales por nombre.
- **Inicio:** continuar viendo y vistos recientemente.
- **TV:** grupos (Favoritos, Todos, tus grupos), vista previa con el programa actual y guía EPG en grilla.
  OK = vista previa; OK otra vez = pantalla completa; OK largo = favorito; izquierda/derecha = programas.
- **Ajustes:** General, Listas, EPG, Apariencia, Reproducción, Mando a distancia, Control parental y Otro.

## Pantalla completa

Arriba/abajo o CH+/CH- cambian de canal, los números saltan directo, OK muestra el cartel, OK largo = favorito, Atrás vuelve.

## Motor de reproducción (PlayerEngine.kt)

- AndroidX Media3 / ExoPlayer.
- Buffer "Medio" por defecto: 15 s mínimo, 40 s máximo, 2,5 s para arrancar, 5 s tras un corte (5 tamaños a elegir).
- Hardware primero; si falla, pasa solo a software (modo automático).
- MPEG-TS directo, HLS, redirecciones http/https, User-Agent configurable.
- Reintentos con espera creciente (1, 2, 4, 8, 10 s) y vigilante anti-congelamiento.
- Tope de 1080p y de memoria; la guía EPG va en SQLite y los logos usan un caché chico.

## Pendiente de probar

El código no se compiló ni se probó en un equipo real. Portal Stalker en particular no se probó contra ningún portal.
