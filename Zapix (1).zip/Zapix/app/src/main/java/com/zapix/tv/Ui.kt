package com.zapix.tv

import android.app.Activity
import android.app.AlertDialog
import android.text.InputFilter
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Diálogos simples que funcionan con el control remoto y con el dedo. */
object Ui {

    fun toast(act: Activity, msg: String) {
        Toast.makeText(act, msg, Toast.LENGTH_SHORT).show()
    }

    fun choice(act: Activity, title: String, options: List<String>, selected: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(act)
            .setTitle(title)
            .setSingleChoiceItems(options.toTypedArray(), selected) { dialog, which ->
                dialog.dismiss()
                onPick(which)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    fun multi(act: Activity, title: String, options: List<String>, checked: BooleanArray, onDone: (BooleanArray) -> Unit) {
        AlertDialog.Builder(act)
            .setTitle(title)
            .setMultiChoiceItems(options.toTypedArray(), checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Aceptar") { _, _ -> onDone(checked) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    fun confirm(act: Activity, title: String, message: String, onYes: () -> Unit) {
        AlertDialog.Builder(act)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Sí") { _, _ -> onYes() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    fun info(act: Activity, title: String, message: String) {
        AlertDialog.Builder(act).setTitle(title).setMessage(message).setPositiveButton("Aceptar", null).show()
    }

    /** Formulario con varios campos de texto. Los índices de [passwordIdx] se escriben como contraseña. */
    fun form(
        act: Activity,
        title: String,
        labels: List<String>,
        initial: List<String>,
        passwordIdx: Set<Int>,
        onOk: (List<String>) -> Unit
    ) {
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }
        val fields = ArrayList<EditText>()
        labels.forEachIndexed { i, label ->
            box.addView(TextView(act).apply {
                text = label
                textSize = 14f
            })
            val et = EditText(act).apply {
                setText(initial.getOrElse(i) { "" })
                setSingleLine()
                inputType = InputType.TYPE_CLASS_TEXT or
                    (if (i in passwordIdx) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS)
            }
            fields.add(et)
            box.addView(et)
        }
        val scroll = ScrollView(act).apply { addView(box) }
        AlertDialog.Builder(act)
            .setTitle(title)
            .setView(scroll)
            .setPositiveButton("Guardar") { _, _ -> onOk(fields.map { it.text.toString().trim() }) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    /** Pide un PIN numérico de 4 dígitos. */
    fun pin(act: Activity, title: String, onOk: (String) -> Unit) {
        val et = EditText(act).apply {
            setSingleLine()
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            filters = arrayOf(InputFilter.LengthFilter(4))
        }
        val box = LinearLayout(act).apply {
            setPadding(48, 24, 48, 0)
            addView(et, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        AlertDialog.Builder(act)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("Aceptar") { _, _ -> onOk(et.text.toString()) }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
