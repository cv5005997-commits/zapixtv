package com.zapix.tv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.View
import android.widget.ListView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Ventana de tiempo que muestra la guía: 3 horas. */
class EpgWindow {
    var startMs = 0L
    val minutes = 180

    fun endMs(): Long = startMs + minutes * 60_000L

    /** Empieza media hora antes de ahora, redondeado a :00 o :30. */
    fun resetToNow(now: Long) {
        startMs = (now / 1_800_000L) * 1_800_000L - 1_800_000L
    }
}

/** Fila de horas arriba de la guía. */
class EpgHeaderView(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    var windowStart = 0L
    var windowMinutes = 180
    var leftOffsetPx = 0
    var textFactor = 1f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hourFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dayFmt = SimpleDateFormat("EEE, d MMM, HH:mm", Locale.getDefault())

    override fun onDraw(canvas: Canvas) {
        if (windowStart == 0L) return
        val dm = resources.displayMetrics
        paint.textSize = 14f * dm.scaledDensity * textFactor
        val baseline = height / 2f - (paint.ascent() + paint.descent()) / 2f

        // Fecha y hora actual, a la izquierda (como TiviMate)
        paint.color = 0xFF7FB4FF.toInt()
        canvas.drawText(dayFmt.format(Date(System.currentTimeMillis())), 8f * dm.density, baseline, paint)

        val avail = (width - leftOffsetPx).toFloat()
        if (avail <= 0f) return
        val ppm = avail / windowMinutes
        paint.color = 0xFF9AA4B2.toInt()
        var t = ((windowStart + 1_799_999L) / 1_800_000L) * 1_800_000L
        val end = windowStart + windowMinutes * 60_000L
        while (t < end) {
            val x = leftOffsetPx + (t - windowStart) / 60_000f * ppm
            val h = hourFmt.format(Date(t))
            canvas.drawText(if (h == "00:00") dayFmt.format(Date(t)) else h, x + 4f * dm.density, baseline, paint)
            t += 1_800_000L
        }
    }
}

/** Una fila de la guía: dibuja los programas de un canal sobre la ventana de tiempo. */
class EpgStripView(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    var programs: List<Program> = emptyList()
    var selected = -1
    var windowStart = 0L
    var windowMinutes = 180
    var nowMs = 0L
    var textFactor = 1f

    private val density = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint()
    private val rect = RectF()

    init {
        line.color = 0xFF4DA3FF.toInt()
        line.strokeWidth = 2f * density
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || windowStart == 0L) return
        text.textSize = 17f * resources.displayMetrics.scaledDensity * textFactor
        val ppm = w / windowMinutes
        val windowEnd = windowStart + windowMinutes * 60_000L

        if (programs.isEmpty()) {
            cell(canvas, 0f, w, h, "Sin información", DIM)
        } else {
            programs.forEachIndexed { i, p ->
                val s = maxOf(p.start, windowStart)
                val e = minOf(p.stop, windowEnd)
                if (e > s) {
                    val x0 = (s - windowStart) / 60_000f * ppm
                    val x1 = (e - windowStart) / 60_000f * ppm
                    cell(canvas, x0, x1, h, p.title, if (i == selected) SEL else NORMAL)
                }
            }
        }
        if (nowMs in windowStart..windowEnd) {
            val x = (nowMs - windowStart) / 60_000f * ppm
            canvas.drawLine(x, 0f, x, h, line)
        }
    }

    private fun cell(canvas: Canvas, x0: Float, x1: Float, h: Float, label: String, mode: Int) {
        val gap = 3f * density
        rect.set(x0 + gap / 2, gap / 2, x1 - gap / 2, h - gap / 2)
        fill.color = when (mode) {
            SEL -> 0xFFE3E3E3.toInt()
            DIM -> 0xFF23262C.toInt()
            else -> 0xFF3A3D44.toInt()
        }
        canvas.drawRoundRect(rect, 4f * density, 4f * density, fill)
        text.color = when (mode) {
            SEL -> 0xFF111111.toInt()
            DIM -> 0xFF7A808B.toInt()
            else -> Color.WHITE
        }
        val baseline = h / 2f - (text.ascent() + text.descent()) / 2f
        canvas.save()
        canvas.clipRect(rect)
        canvas.drawText(label, rect.left + 10f * density, baseline, text)
        canvas.restore()
    }

    private companion object {
        const val NORMAL = 0
        const val SEL = 1
        const val DIM = 2
    }
}

/** Lista de canales de la guía: izquierda y derecha mueven entre los programas del canal elegido. */
class ChannelListView(context: Context, attrs: AttributeSet?) : ListView(context, attrs) {
    var onLeft: (() -> Boolean)? = null
    var onRight: (() -> Boolean)? = null

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT && onLeft?.invoke() == true) return true
        if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && onRight?.invoke() == true) return true
        return super.onKeyDown(keyCode, event)
    }
}
