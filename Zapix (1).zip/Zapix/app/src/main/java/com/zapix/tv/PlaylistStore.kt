package com.zapix.tv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Guarda las listas del usuario (puede haber varias; una está activa). */
class PlaylistStore(private val context: Context, private val settings: Settings) {

    fun all(): List<Source> {
        val out = ArrayList<Source>()
        try {
            val arr = JSONArray(settings.sourcesJson)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Source(
                        o.getString("id"), o.getInt("type"), o.getString("name"),
                        o.optString("a"), o.optString("b"), o.optString("c")
                    )
                )
            }
        } catch (e: Exception) {
            // lista corrupta: se ignora
        }
        return out
    }

    private fun save(list: List<Source>) {
        val arr = JSONArray()
        for (s in list) {
            arr.put(
                JSONObject()
                    .put("id", s.id).put("type", s.type).put("name", s.name)
                    .put("a", s.a).put("b", s.b).put("c", s.c)
            )
        }
        settings.sourcesJson = arr.toString()
    }

    fun active(): Source? {
        val list = all()
        return list.firstOrNull { it.id == settings.activeSource } ?: list.firstOrNull()
    }

    fun setActive(id: String) {
        settings.activeSource = id
    }

    fun add(s: Source) {
        save(all() + s)
        settings.activeSource = s.id
    }

    fun remove(id: String) {
        cacheFile(id).delete()
        val rest = all().filter { it.id != id }
        save(rest)
        if (settings.activeSource == id) settings.activeSource = rest.firstOrNull()?.id ?: ""
    }

    fun cacheFile(id: String): File = File(context.filesDir, "pl_$id.m3u")

    fun newId(): String = System.currentTimeMillis().toString(36)
}
