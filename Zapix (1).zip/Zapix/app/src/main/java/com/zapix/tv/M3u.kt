package com.zapix.tv

import java.io.File

object M3u {

    class Result(val channels: List<Channel>, val epgUrl: String)

    /** Lee la lista línea por línea: poca memoria incluso con miles de canales. */
    fun parse(file: File, sortAz: Boolean): Result {
        val raw = ArrayList<Channel>()
        var epgUrl = ""
        var name: String? = null
        var group = ""
        var logo = ""
        var tvgId = ""
        var chno = 0

        file.bufferedReader().useLines { lines ->
            for (rawLine in lines) {
                val line = rawLine.trim()
                if (line.isEmpty()) continue
                when {
                    line.startsWith("#EXTM3U") -> {
                        val u = attr(line, "url-tvg").ifEmpty { attr(line, "x-tvg-url") }
                        if (u.isNotEmpty()) epgUrl = u.substringBefore(',').trim()
                    }
                    line.startsWith("#EXTINF") -> {
                        val lastQuote = line.lastIndexOf('"')
                        val comma = line.indexOf(',', if (lastQuote > 0) lastQuote else 0)
                        name = if (comma >= 0) line.substring(comma + 1).trim() else ""
                        group = attr(line, "group-title").trim()
                        logo = attr(line, "tvg-logo").trim()
                        tvgId = attr(line, "tvg-id").trim().lowercase()
                        chno = attr(line, "tvg-chno").trim().toIntOrNull() ?: 0
                    }
                    line.startsWith("#EXTGRP:") -> group = line.substring(8).trim()
                    line.startsWith("#") -> Unit
                    else -> {
                        val n = name
                        raw.add(Channel(chno, if (n.isNullOrEmpty()) line else n, group, line, logo, tvgId))
                        name = null
                        group = ""
                        logo = ""
                        tvgId = ""
                        chno = 0
                    }
                }
            }
        }

        val ordered: List<Channel> = if (sortAz) raw.sortedBy { it.name.lowercase() } else raw
        val numbered = ordered.mapIndexed { i, c ->
            c.copy(number = if (sortAz || c.number <= 0) i + 1 else c.number)
        }
        return Result(numbered, epgUrl)
    }

    private fun attr(line: String, key: String): String {
        val k = "$key=\""
        val i = line.indexOf(k)
        if (i < 0) return ""
        val s = i + k.length
        val e = line.indexOf('"', s)
        return if (e < 0) "" else line.substring(s, e)
    }
}
