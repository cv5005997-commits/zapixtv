package com.zapix.tv

import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object Http {

    /** Abre la conexión siguiendo redirecciones, también entre http y https. */
    @Throws(IOException::class)
    fun open(
        urlStr: String,
        userAgent: String,
        timeoutMs: Int,
        headers: Map<String, String> = emptyMap()
    ): HttpURLConnection {
        var target = urlStr
        var redirects = 0
        while (true) {
            val conn = URL(target).openConnection() as HttpURLConnection
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs * 2
            conn.instanceFollowRedirects = false
            conn.setRequestProperty("User-Agent", userAgent)
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            val code = conn.responseCode
            if (code in 300..399 && redirects < 5) {
                val loc = conn.getHeaderField("Location")
                conn.disconnect()
                if (loc == null) throw IOException("Redirección sin destino")
                target = URL(URL(target), loc).toString()
                redirects++
                continue
            }
            if (code !in 200..299) {
                conn.disconnect()
                throw IOException("HTTP $code")
            }
            return conn
        }
    }

    /** Baja a un archivo sin cargarlo en memoria. Si falla, no pisa el archivo anterior. */
    @Throws(IOException::class)
    fun download(urlStr: String, userAgent: String, dest: File, timeoutMs: Int) {
        val conn = open(urlStr, userAgent, timeoutMs)
        try {
            val tmp = File(dest.parentFile, dest.name + ".tmp")
            conn.inputStream.use { input -> tmp.outputStream().use { out -> input.copyTo(out) } }
            if (dest.exists()) dest.delete()
            if (!tmp.renameTo(dest)) throw IOException("No se pudo guardar el archivo")
        } finally {
            conn.disconnect()
        }
    }

    @Throws(IOException::class)
    fun getString(
        urlStr: String,
        userAgent: String,
        timeoutMs: Int,
        headers: Map<String, String> = emptyMap()
    ): String {
        val conn = open(urlStr, userAgent, timeoutMs, headers)
        try {
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
