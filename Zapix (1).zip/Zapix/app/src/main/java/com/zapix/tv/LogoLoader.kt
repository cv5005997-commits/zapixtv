package com.zapix.tv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.io.File
import java.util.concurrent.Executors

/**
 * Carga de logos sin librerías: caché en memoria de 4 MB y caché en disco.
 * Los logos se reducen a 96 px para que no pesen en una TV de 1 GB.
 */
class LogoLoader(context: Context) {

    private val memory = object : LruCache<String, Bitmap>(4 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val dir = File(context.cacheDir, "logos").apply { mkdirs() }
    private val pool = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())
    private val failed = HashSet<String>()

    fun load(url: String, view: ImageView) {
        view.tag = url
        if (url.isEmpty()) {
            view.setImageResource(R.drawable.ic_tv_placeholder)
            return
        }
        val hit = memory.get(url)
        if (hit != null) {
            view.setImageBitmap(hit)
            return
        }
        view.setImageResource(R.drawable.ic_tv_placeholder)
        synchronized(failed) { if (failed.contains(url)) return }
        pool.execute {
            // La fila ya se reutilizó para otro canal: no vale la pena bajar este logo
            if (view.tag != url) return@execute
            val bmp = fetch(url)
            if (bmp != null) {
                memory.put(url, bmp)
                main.post { if (view.tag == url) view.setImageBitmap(bmp) }
            } else {
                synchronized(failed) { failed.add(url) }
            }
        }
    }

    fun clearCache() {
        memory.evictAll()
        synchronized(failed) { failed.clear() }
        dir.listFiles()?.forEach { it.delete() }
    }

    private fun fetch(url: String): Bitmap? {
        return try {
            val file = File(dir, Integer.toHexString(url.hashCode()) + ".img")
            if (!file.exists()) {
                val conn = Http.open(url, "Mozilla/5.0", 8_000)
                try {
                    val bytes = conn.inputStream.use { it.readBytes() }
                    if (bytes.size > 600_000) return null
                    file.writeBytes(bytes)
                } finally {
                    conn.disconnect()
                }
            }
            decode(file)
        } catch (e: Exception) {
            null
        }
    }

    private fun decode(file: File): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        var sample = 1
        val maxSide = maxOf(bounds.outWidth, bounds.outHeight)
        while (maxSide / sample > 192) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(file.path, opts)
    }
}
