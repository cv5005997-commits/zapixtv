package com.zapix.tv

import android.content.Context
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** Todos los ajustes de Zapix. Ninguno está bloqueado. */
class Settings(context: Context) {

    private val sp = context.getSharedPreferences("zapix_settings", Context.MODE_PRIVATE)

    private inner class IntPref(val key: String, val def: Int) : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Int = sp.getInt(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            sp.edit().putInt(key, value).apply()
        }
    }

    private inner class BoolPref(val key: String, val def: Boolean) : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = sp.getBoolean(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            sp.edit().putBoolean(key, value).apply()
        }
    }

    private inner class StrPref(val key: String, val def: String) : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): String = sp.getString(key, def) ?: def
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            sp.edit().putString(key, value).apply()
        }
    }

    private inner class LongPref(val key: String, val def: Long) : ReadWriteProperty<Any?, Long> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Long = sp.getLong(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Long) {
            sp.edit().putLong(key, value).apply()
        }
    }

    // ---- General ----
    var startMode by IntPref("start_mode", 0)            // 0 Inicio, 1 TV, 2 último canal a pantalla completa
    var bannerSeconds by IntPref("banner_seconds", 4)
    var sortAz by BoolPref("sort_az", false)
    var zapInGroup by BoolPref("zap_in_group", true)

    // ---- Listas ----
    var refreshOnOpen by BoolPref("refresh_on_open", true)
    var sourcesJson by StrPref("sources_json", "[]")
    var activeSource by StrPref("active_source", "")

    // ---- EPG ----
    var epgUrl by StrPref("epg_url", "")                 // vacío = automática (la que trae la lista)
    var epgHours by IntPref("epg_hours", 12)             // 0 = solo manual
    var epgOffsetHours by IntPref("epg_offset_hours", 0)
    var epgLastUpdate by LongPref("epg_last_update", 0L)

    // ---- Apariencia ----
    var textScale by IntPref("text_scale", 1)            // 0 pequeño, 1 normal, 2 grande
    var showLogos by BoolPref("show_logos", true)
    var showNumbers by BoolPref("show_numbers", true)

    // ---- Reproducción ----
    var bufferIndex by IntPref("buffer_index", BufferPreset.DEFAULT_INDEX)
    var decoderMode by IntPref("decoder_mode", 0)        // 0 automático (hardware y software), 1 solo hardware
    var aspectMode by IntPref("aspect_mode", 0)          // 0 auto, 1 16:9, 2 4:3, 3 estirar, 4 zoom
    var maxHeight by IntPref("max_height", 1080)         // 720, 1080 o 0 = sin límite
    var userAgent by StrPref("user_agent", DEFAULT_UA)
    var timeoutSec by IntPref("timeout_sec", 10)
    var autoRetry by BoolPref("auto_retry", true)

    // ---- Mando a distancia ----
    var invertUpDown by BoolPref("invert_up_down", false)
    var okInFull by IntPref("ok_in_full", 0)             // 0 mostrar información, 1 volver a la lista
    var leftRight by IntPref("left_right", 0)            // 0 nada, 1 cambiar de canal

    // ---- Control parental ----
    var pin by StrPref("pin", "")
    var lockSettings by BoolPref("lock_settings", false)

    // ---- Estado ----
    var lastUrl by StrPref("last_url", "")

    fun textFactor(): Float = when (textScale) {
        0 -> 0.85f
        2 -> 1.2f
        else -> 1f
    }

    // ---- Favoritos ----
    private var favCache: HashSet<String>? = null

    private fun favs(): HashSet<String> {
        var f = favCache
        if (f == null) {
            f = HashSet<String>((sp.getString("favorites", "") ?: "").split('\n').filter { it.isNotEmpty() })
            favCache = f
        }
        return f
    }

    fun isFavorite(url: String): Boolean = favs().contains(url)

    /** Devuelve true si quedó como favorito. */
    fun toggleFavorite(url: String): Boolean {
        val f = favs()
        val on = if (f.contains(url)) {
            f.remove(url)
            false
        } else {
            f.add(url)
            true
        }
        sp.edit().putString("favorites", f.joinToString("\n")).apply()
        return on
    }

    // ---- Grupos bloqueados ----
    fun lockedGroups(): Set<String> =
        (sp.getString("locked_groups", "") ?: "").split('\n').filter { it.isNotEmpty() }.toSet()

    fun setLockedGroups(groups: Set<String>) {
        sp.edit().putString("locked_groups", groups.joinToString("\n")).apply()
    }

    // ---- Vistos recientemente ----
    fun recents(): List<String> =
        (sp.getString("recents", "") ?: "").split('\n').filter { it.isNotEmpty() }

    fun pushRecent(url: String) {
        val l = (listOf(url) + recents().filter { it != url }).take(12)
        sp.edit().putString("recents", l.joinToString("\n")).apply()
    }

    // ---- Datos sueltos (por ejemplo, la guía que trae cada lista) ----
    fun extra(key: String): String = sp.getString("x_$key", "") ?: ""

    fun setExtra(key: String, value: String) {
        sp.edit().putString("x_$key", value).apply()
    }

    /** Vuelve los ajustes a su valor original, pero conserva tus listas, favoritos y PIN. */
    fun resetAll() {
        val keep = listOf("sources_json", "active_source", "favorites", "pin", "locked_groups", "recents")
        val saved = keep.associateWith { sp.getString(it, null) }
        sp.edit().clear().apply()
        val e = sp.edit()
        for ((k, v) in saved) if (v != null) e.putString(k, v)
        e.apply()
        favCache = null
    }

    companion object {
        const val DEFAULT_UA = "Zapix/1.0 (Android)"
        const val BROWSER_UA =
            "Mozilla/5.0 (Linux; Android 10; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
    }
}
