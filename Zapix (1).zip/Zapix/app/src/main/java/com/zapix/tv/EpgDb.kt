package com.zapix.tv

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.util.GregorianCalendar
import java.util.TimeZone
import java.util.zip.GZIPInputStream

/**
 * Guía de programación (XMLTV) guardada en SQLite.
 * Se lee en streaming y solo se guardan los canales de tu lista y las próximas ~36 horas,
 * así no ocupa memoria aunque el archivo de la guía sea enorme.
 */
class EpgDb(context: Context) : SQLiteOpenHelper(context, "epg.db", null, 1) {

    private val cal = GregorianCalendar(TimeZone.getTimeZone("UTC"))

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE prog(ch TEXT, st INTEGER, en INTEGER, title TEXT, descr TEXT)")
        db.execSQL("CREATE INDEX idx_prog ON prog(ch, st)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS prog")
        onCreate(db)
    }

    /** Programas de un canal entre [from] y [to]. [offsetMs] es el desfase horario de los ajustes. */
    fun programs(epgId: String, from: Long, to: Long, offsetMs: Long): List<Program> {
        val out = ArrayList<Program>()
        try {
            readableDatabase.rawQuery(
                "SELECT st,en,title,descr FROM prog WHERE ch=? AND en>? AND st<? ORDER BY st",
                arrayOf(epgId, (from - offsetMs).toString(), (to - offsetMs).toString())
            ).use { c ->
                while (c.moveToNext()) {
                    out.add(Program(c.getLong(0) + offsetMs, c.getLong(1) + offsetMs, c.getString(2) ?: "", c.getString(3) ?: ""))
                }
            }
        } catch (e: Exception) {
            // base ocupada: se muestra "Sin información" y se reintenta después
        }
        return out
    }

    /** Programa que se está emitiendo ahora, o null. */
    fun current(epgId: String, nowMs: Long, offsetMs: Long): Program? {
        if (epgId.isEmpty()) return null
        return programs(epgId, nowMs, nowMs + 1, offsetMs).firstOrNull { it.start <= nowMs && it.stop > nowMs }
    }

    fun clear() {
        try {
            writableDatabase.execSQL("DELETE FROM prog")
        } catch (e: Exception) {
            // nada
        }
    }

    /** Baja la guía, la importa y borra el archivo temporal. Devuelve cuántos programas guardó. */
    @Throws(Exception::class)
    fun refresh(url: String, userAgent: String, timeoutMs: Int, wanted: Set<String>, tmpDir: File): Int {
        val file = File(tmpDir, "epg_download.tmp")
        Http.download(url, userAgent, file, timeoutMs * 3)
        try {
            val raw = BufferedInputStream(FileInputStream(file))
            raw.mark(2)
            val b1 = raw.read()
            val b2 = raw.read()
            raw.reset()
            val input: InputStream = if (b1 == 0x1f && b2 == 0x8b) GZIPInputStream(raw) else raw
            val now = System.currentTimeMillis()
            input.use { return importXmltv(it, wanted, now - 3 * HOUR, now + 36 * HOUR) }
        } finally {
            file.delete()
        }
    }

    private fun importXmltv(input: InputStream, wanted: Set<String>, from: Long, to: Long): Int {
        val db = writableDatabase
        var count = 0
        db.beginTransaction()
        try {
            db.execSQL("DELETE FROM prog")
            val stmt = db.compileStatement("INSERT INTO prog(ch,st,en,title,descr) VALUES(?,?,?,?,?)")
            val p = Xml.newPullParser()
            p.setInput(input, null)
            var ch = ""
            var st = 0L
            var en = 0L
            var title = ""
            var desc = ""
            var inProg = false
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "programme" -> {
                            inProg = true
                            ch = (p.getAttributeValue(null, "channel") ?: "").lowercase()
                            st = parseTime(p.getAttributeValue(null, "start"))
                            en = parseTime(p.getAttributeValue(null, "stop"))
                            title = ""
                            desc = ""
                        }
                        "title" -> if (inProg && title.isEmpty()) title = p.nextText()
                        "desc" -> if (inProg && desc.isEmpty()) desc = p.nextText()
                    }
                } else if (ev == XmlPullParser.END_TAG && p.name == "programme") {
                    inProg = false
                    if (ch.isNotEmpty() && en > from && st < to && (wanted.isEmpty() || wanted.contains(ch))) {
                        stmt.clearBindings()
                        stmt.bindString(1, ch)
                        stmt.bindLong(2, st)
                        stmt.bindLong(3, en)
                        stmt.bindString(4, title)
                        stmt.bindString(5, desc.take(300))
                        stmt.executeInsert()
                        count++
                    }
                }
                ev = p.next()
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return count
    }

    /** Hora de XMLTV: 20261125230000 +0000 */
    private fun parseTime(s: String?): Long {
        if (s == null) return 0L
        val t = s.trim()
        if (t.length < 12) return 0L
        return try {
            cal.clear()
            cal.set(
                t.substring(0, 4).toInt(),
                t.substring(4, 6).toInt() - 1,
                t.substring(6, 8).toInt(),
                t.substring(8, 10).toInt(),
                t.substring(10, 12).toInt(),
                if (t.length >= 14) t.substring(12, 14).toInt() else 0
            )
            var ms = cal.timeInMillis
            val sp = t.indexOf(' ')
            if (sp > 0 && t.length >= sp + 6) {
                val sign = if (t[sp + 1] == '-') -1 else 1
                val oh = t.substring(sp + 2, sp + 4).toInt()
                val om = t.substring(sp + 4, sp + 6).toInt()
                ms -= sign * (oh * 60 + om) * 60_000L
            }
            ms
        } catch (e: Exception) {
            0L
        }
    }

    companion object {
        const val HOUR = 3_600_000L
    }
}
