package com.zapix.tv

import android.net.Uri
import android.util.JsonReader
import android.util.JsonToken
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.io.Writer

/**
 * Cliente de Portal Stalker (MAG / Ministra).
 * Baja los canales a un archivo con formato M3U (url "stalker://<lista>/<cmd>") y, al reproducir,
 * pide el enlace real con create_link. Todavía no se probó contra un portal real.
 */
class StalkerClient(portal: String, private val mac: String, private val timeoutMs: Int = 15_000) {

    private val endpoint: String
    private var token = ""

    private val ua =
        "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"

    init {
        var p = portal.trim()
        if (!p.startsWith("http")) p = "http://$p"
        p = p.trimEnd('/')
        endpoint = if (p.contains(".php")) {
            p
        } else {
            val base = if (p.endsWith("/c")) p.substring(0, p.length - 2) else p
            "$base/server/load.php"
        }
    }

    private fun headers(): Map<String, String> {
        val h = HashMap<String, String>()
        h["Cookie"] = "mac=$mac; stb_lang=en; timezone=UTC"
        h["X-User-Agent"] = "Model: MAG250; Link: WiFi"
        if (token.isNotEmpty()) h["Authorization"] = "Bearer $token"
        return h
    }

    private fun call(query: String): String =
        Http.getString("$endpoint?$query&JsHttpRequest=1-xml", ua, timeoutMs, headers())

    @Throws(IOException::class)
    fun handshake() {
        token = ""
        val r = JSONObject(call("type=stb&action=handshake&token="))
        token = r.optJSONObject("js")?.optString("token") ?: ""
        if (token.isEmpty()) throw IOException("El portal no devolvió token")
        try {
            call("type=stb&action=get_profile&hd=1&num_banks=2&stb_type=MAG250&client_type=STB&image_version=218&video_out=hdmi&auth_second_step=1&hw_version=1.7-BD-00&not_valid_token=0")
        } catch (e: Exception) {
            // algunos portales no lo necesitan
        }
    }

    private fun genres(): Map<String, String> {
        val out = HashMap<String, String>()
        try {
            val arr = JSONObject(call("type=itv&action=get_genres")).optJSONArray("js") ?: return out
            for (i in 0 until arr.length()) {
                val g = arr.optJSONObject(i) ?: continue
                out[g.optString("id")] = g.optString("title")
            }
        } catch (e: Exception) {
            // sin grupos: los canales quedan en "Sin grupo"
        }
        return out
    }

    /** Escribe los canales en [dest] con formato M3U y devuelve cuántos son. */
    @Throws(IOException::class)
    fun downloadChannels(sourceId: String, dest: File): Int {
        handshake()
        val genreNames = genres()
        val conn = Http.open(
            "$endpoint?type=itv&action=get_all_channels&JsHttpRequest=1-xml", ua, timeoutMs, headers()
        )
        val tmp = File(dest.parentFile, dest.name + ".tmp")
        var count = 0
        try {
            JsonReader(InputStreamReader(conn.inputStream, "UTF-8")).use { reader ->
                tmp.bufferedWriter().use { w ->
                    w.write("#EXTM3U\n")
                    count = readRoot(reader, sourceId, genreNames, w)
                }
            }
        } finally {
            conn.disconnect()
        }
        if (count == 0) {
            tmp.delete()
            throw IOException("El portal no devolvió canales")
        }
        if (dest.exists()) dest.delete()
        if (!tmp.renameTo(dest)) throw IOException("No se pudo guardar la lista")
        return count
    }

    private fun readRoot(r: JsonReader, id: String, genres: Map<String, String>, w: Writer): Int {
        var n = 0
        r.beginObject()
        while (r.hasNext()) {
            if (r.nextName() == "js") {
                when (r.peek()) {
                    JsonToken.BEGIN_OBJECT -> {
                        r.beginObject()
                        while (r.hasNext()) {
                            if (r.nextName() == "data" && r.peek() == JsonToken.BEGIN_ARRAY) {
                                n += readArray(r, id, genres, w)
                            } else {
                                r.skipValue()
                            }
                        }
                        r.endObject()
                    }
                    JsonToken.BEGIN_ARRAY -> n += readArray(r, id, genres, w)
                    else -> r.skipValue()
                }
            } else {
                r.skipValue()
            }
        }
        r.endObject()
        return n
    }

    private fun readArray(r: JsonReader, id: String, genres: Map<String, String>, w: Writer): Int {
        var n = 0
        r.beginArray()
        while (r.hasNext()) {
            if (r.peek() == JsonToken.BEGIN_OBJECT) {
                if (writeChannel(r, id, genres, w)) n++
            } else {
                r.skipValue()
            }
        }
        r.endArray()
        return n
    }

    private fun str(r: JsonReader): String = when (r.peek()) {
        JsonToken.STRING, JsonToken.NUMBER -> r.nextString()
        JsonToken.NULL -> {
            r.nextNull()
            ""
        }
        else -> {
            r.skipValue()
            ""
        }
    }

    private fun clean(s: String): String = s.replace('"', '\'').replace('\n', ' ').replace('\r', ' ').trim()

    private fun writeChannel(r: JsonReader, id: String, genres: Map<String, String>, w: Writer): Boolean {
        var name = ""
        var cmd = ""
        var logo = ""
        var genre = ""
        var xmltv = ""
        var number = ""
        r.beginObject()
        while (r.hasNext()) {
            when (r.nextName()) {
                "name" -> name = str(r)
                "cmd" -> cmd = str(r)
                "logo" -> logo = str(r)
                "tv_genre_id" -> genre = str(r)
                "xmltv_id" -> xmltv = str(r)
                "number" -> number = str(r)
                else -> r.skipValue()
            }
        }
        r.endObject()
        if (cmd.isEmpty() || name.isEmpty()) return false
        val logoUrl = if (logo.startsWith("http")) logo else ""
        w.write(
            "#EXTINF:-1 tvg-id=\"${clean(xmltv)}\" tvg-logo=\"${clean(logoUrl)}\" tvg-chno=\"${clean(number)}\" " +
                "group-title=\"${clean(genres[genre] ?: "")}\",${clean(name)}\n"
        )
        w.write("stalker://$id/${Uri.encode(cmd)}\n")
        return true
    }

    /** Pide el enlace real de reproducción de un canal. */
    @Throws(IOException::class)
    fun createLink(cmd: String): String {
        if (token.isEmpty()) handshake()
        val query = "type=itv&action=create_link&cmd=${Uri.encode(cmd)}&series=&forced_storage=0&disable_ip_check=0&download=0"
        val json = try {
            JSONObject(call(query))
        } catch (e: Exception) {
            handshake()
            JSONObject(call(query))
        }
        var link = json.optJSONObject("js")?.optString("cmd") ?: ""
        if (link.isEmpty()) throw IOException("El portal no devolvió el enlace")
        val space = link.indexOf(' ')
        if (space > 0 && !link.startsWith("http")) link = link.substring(space + 1)
        return link.trim()
    }
}
