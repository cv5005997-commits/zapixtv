# Zapix

Reproductor de listas M3U para Android TV, pensado para equipos de 1 GB de RAM.
Tres apartados: **Inicio**, **TV** y **Ajustes**.

## Compilar el APK (GitHub Actions)

1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta (incluida `.github`).
2. En la pestaña **Actions** espera a que termine "Compilar APK".
3. Descarga el artefacto **Zapix-apk**: dentro está `app-release.apk`.
4. Instálalo en la TV (USB, "Send Files to TV" o `adb install app-release.apk`).

## Uso con el control remoto

- **Pestañas:** mueve izquierda/derecha para cambiar entre Inicio, TV y Ajustes; abajo para entrar.
- **TV:** elige grupo a la izquierda y canal a la derecha. OK = vista previa; OK otra vez = pantalla completa.
- **Pantalla completa:** arriba/abajo o CH+/CH- cambian de canal; los números saltan directo al canal;
  OK muestra el nombre; Atrás vuelve a la lista.
- **Inicio:** "Continuar" y los canales vistos recientemente.
- **Ajustes:** URL de la lista, User-Agent y tamaño del buffer.

## Motor de reproducción (PlayerEngine.kt)

- Buffer "Medio" por defecto: 15 s mínimo, 40 s máximo, 2,5 s para arrancar, 5 s tras un corte.
- Decodificador por hardware con respaldo automático a software.
- MPEG-TS directo, HLS, redirecciones http/https, User-Agent configurable.
- Reintentos con espera creciente y vigilante anti-congelamiento.
