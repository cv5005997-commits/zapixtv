package com.zapix.tv

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.SurfaceView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory

/**
 * Motor de reproducción de Zapix, pensado para una TV Android de 1 GB de RAM.
 *
 * - Buffers según el preset elegido (por defecto 15 s mínimo / 40 s máximo).
 * - Decodificador por hardware; si falla, pasa solo a software.
 * - MPEG-TS directo, HLS, redirecciones http/https y User-Agent configurable.
 * - Reintentos automáticos con espera creciente y vigilante anti-congelamiento.
 */
class PlayerEngine(
    context: Context,
    userAgent: String,
    preset: BufferPreset,
    private val onStatus: (String?) -> Unit,
    private val onVideoAspect: (Float) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val player: ExoPlayer

    private var current: Channel? = null
    private var retry = 0
    private var forceHls = false
    private var released = false

    // Vigilante anti-congelamiento
    private var lastPos = -1L
    private var lastMove = 0L
    private var bufferingSince = 0L

    private val retryRunnable = Runnable { start() }

    private val watchdog = object : Runnable {
        override fun run() {
            if (released) return
            val now = SystemClock.elapsedRealtime()
            when (player.playbackState) {
                Player.STATE_READY -> {
                    bufferingSince = 0L
                    if (player.playWhenReady) {
                        val pos = player.currentPosition
                        if (pos != lastPos) {
                            lastPos = pos
                            lastMove = now
                        } else if (now - lastMove > FREEZE_MS) {
                            // La imagen quedó clavada: volver a conectar el canal
                            onStatus("Reanudando…")
                            start()
                        }
                    }
                }
                Player.STATE_BUFFERING -> {
                    if (bufferingSince == 0L) {
                        bufferingSince = now
                    } else if (now - bufferingSince > STALL_MS) {
                        bufferingSince = 0L
                        onStatus("Reconectando…")
                        start()
                    }
                }
                else -> bufferingSince = 0L
            }
            main.postDelayed(this, WATCHDOG_INTERVAL_MS)
        }
    }

    init {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(userAgent)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10_000)
            .setReadTimeoutMs(10_000)

        val extractors = DefaultExtractorsFactory().setTsExtractorFlags(
            DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
        )

        val sourceFactory = DefaultMediaSourceFactory(http, extractors)
            .setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(8))

        // Hardware primero; software como respaldo automático.
        val renderers = DefaultRenderersFactory(context)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
            .setEnableDecoderFallback(true)

        // En una TV de 32" no hace falta más de 1080p; evita variantes 4K que ahogan 1 GB de RAM.
        val selector = DefaultTrackSelector(context)
        selector.setParameters(selector.buildUponParameters().setMaxVideoSize(1920, 1080))

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(preset.minMs, preset.maxMs, preset.startMs, preset.rebufferMs)
            .setTargetBufferBytes(preset.maxBytes)
            .setPrioritizeTimeOverSizeThresholds(false)
            .setBackBuffer(0, false) // en vivo no hace falta buffer hacia atrás
            .build()

        player = ExoPlayer.Builder(context, renderers)
            .setMediaSourceFactory(sourceFactory)
            .setTrackSelector(selector)
            .setLoadControl(loadControl)
            .setAudioAttributes(AudioAttributes.DEFAULT, true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_READY -> {
                        retry = 0
                        resetWatch()
                        onStatus(null)
                    }
                    // El servidor cerró la conexión de un canal en vivo: reconectar
                    Player.STATE_ENDED -> scheduleRetry(false)
                }
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) {
                    onVideoAspect(videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height)
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                val parsing = error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
                    error.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED ||
                    error.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED
                scheduleRetry(parsing)
            }
        })

        main.postDelayed(watchdog, WATCHDOG_INTERVAL_MS)
    }

    fun attach(view: SurfaceView) {
        player.setVideoSurfaceView(view)
    }

    fun play(channel: Channel) {
        current = channel
        retry = 0
        forceHls = false
        start()
    }

    fun release() {
        released = true
        main.removeCallbacksAndMessages(null)
        player.release()
    }

    private fun start() {
        val ch = current ?: return
        main.removeCallbacks(retryRunnable)
        val item = MediaItem.Builder()
            .setUri(ch.url)
            .apply { if (forceHls) setMimeType(MimeTypes.APPLICATION_M3U8) }
            .build()
        player.setMediaItem(item)
        player.prepare()
        player.playWhenReady = true
        resetWatch()
    }

    /** Reintento con espera creciente: 1, 2, 4, 8 y luego 10 s, sin límite de intentos. */
    private fun scheduleRetry(toggleHls: Boolean) {
        if (released || current == null) return
        // Si el formato no se reconoce, alternar entre detección automática y HLS forzado
        if (toggleHls) forceHls = !forceHls
        retry++
        val delay = minOf(1000L shl minOf(retry - 1, 4), 10_000L)
        onStatus("Reconectando… ($retry)")
        main.removeCallbacks(retryRunnable)
        main.postDelayed(retryRunnable, delay)
    }

    private fun resetWatch() {
        lastPos = -1L
        lastMove = SystemClock.elapsedRealtime()
        bufferingSince = 0L
    }

    private companion object {
        const val WATCHDOG_INTERVAL_MS = 2_000L
        const val FREEZE_MS = 6_000L
        const val STALL_MS = 20_000L
    }
}
