package com.zapix.tv

/**
 * Tamaños de buffer. El "Medio" es el que sacamos de TiviMate: 15 s mínimo y 40 s máximo.
 * El tope en MB protege la memoria de la TV (1 GB de RAM).
 */
enum class BufferPreset(
    val label: String,
    val minMs: Int,
    val maxMs: Int,
    val startMs: Int,
    val rebufferMs: Int,
    val maxBytes: Int
) {
    CHICO("Chico (8 a 30 s)", 8_000, 30_000, 2_000, 4_000, 16 * 1024 * 1024),
    MEDIO("Medio (15 a 40 s)", 15_000, 40_000, 2_500, 5_000, 24 * 1024 * 1024),
    GRANDE("Grande (25 a 50 s)", 25_000, 50_000, 3_000, 6_000, 32 * 1024 * 1024);

    companion object {
        const val DEFAULT_INDEX = 1

        fun fromIndex(i: Int): BufferPreset = values().getOrElse(i) { MEDIO }
    }
}
