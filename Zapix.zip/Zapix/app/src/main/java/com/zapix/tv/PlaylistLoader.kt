package com.zapix.tv

import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object PlaylistLoader {

    /** Baja la lista a un archivo (sigue redirecciones http y https) sin cargarla entera en memoria. */
    @Throws(IOException::class)
    fun download(urlStr: String, userAgent: String, dest: File) {
        var target = urlStr
        var redirects = 0
        while (true) {
            val conn = URL(target).openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.instanceFollowRedirects = false
            conn.setRequestProperty("User-Agent", userAgent)
            try {
                val code = conn.responseCode
                if (code in 300..399 && redirects < 5) {
                    val loc = conn.getHeaderField("Location") ?: throw IOException("Redirección sin destino")
                    target = URL(URL(target), loc).toString()
                    redirects++
                    continue
                }
                if (code !in 200..299) throw IOException("HTTP $code")
                val tmp = File(dest.parentFile, dest.name + ".tmp")
                conn.inputStream.use { input -> tmp.outputStream().use { out -> input.copyTo(out) } }
                if (dest.exists()) dest.delete()
                if (!tmp.renameTo(dest)) throw IOException("No se pudo guardar la lista")
                return
            } finally {
                conn.disconnect()
            }
        }
    }

    /** Lee la lista línea por línea: poca memoria incluso con miles de canales. */
    fun parse(file: File): List<Channel> {
        val out = ArrayList<Channel>()
        var name: String? = null
        var group = ""
        file.bufferedReader().useLines { lines ->
            for (raw in lines) {
                val line = raw.trim()
                if (line.isEmpty()) continue
                when {
                    line.startsWith("#EXTINF") -> {
                        val lastQuote = line.lastIndexOf('"')
                        val comma = line.indexOf(',', if (lastQuote > 0) lastQuote else 0)
                        name = if (comma >= 0) line.substring(comma + 1).trim() else ""
                        group = attr(line, "group-title")
                    }
                    line.startsWith("#EXTGRP:") -> group = line.substring(8).trim()
                    line.startsWith("#") -> Unit
                    else -> {
                        val n = name
                        out.add(Channel(if (n.isNullOrEmpty()) line else n, group, line))
                        name = null
                        group = ""
                    }
                }
            }
        }
        return out
    }

    private fun attr(line: String, key: String): String {
        val k = "$key=\""
        val i = line.indexOf(k)
        if (i < 0) return ""
        val s = i + k.length
        val e = line.indexOf('"', s)
        return if (e < 0) "" else line.substring(s, e)
    }
}
