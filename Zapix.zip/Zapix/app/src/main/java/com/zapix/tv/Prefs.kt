package com.zapix.tv

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("zapix", Context.MODE_PRIVATE)

    var playlistUrl: String
        get() = sp.getString("playlist_url", "") ?: ""
        set(v) = sp.edit().putString("playlist_url", v).apply()

    var userAgent: String
        get() = sp.getString("user_agent", DEFAULT_UA)?.ifBlank { DEFAULT_UA } ?: DEFAULT_UA
        set(v) = sp.edit().putString("user_agent", v).apply()

    var lastUrl: String
        get() = sp.getString("last_url", "") ?: ""
        set(v) = sp.edit().putString("last_url", v).apply()

    var bufferIndex: Int
        get() = sp.getInt("buffer_index", BufferPreset.DEFAULT_INDEX)
        set(v) = sp.edit().putInt("buffer_index", v).apply()

    /** URLs de los últimos canales vistos, el más reciente primero. */
    var recents: List<String>
        get() = (sp.getString("recents", "") ?: "").split('\n').filter { it.isNotEmpty() }
        set(v) = sp.edit().putString("recents", v.joinToString("\n")).apply()

    fun pushRecent(url: String) {
        recents = (listOf(url) + recents.filter { it != url }).take(MAX_RECENTS)
    }

    companion object {
        const val DEFAULT_UA = "VLC/3.0.20 LibVLC/3.0.20"
        private const val MAX_RECENTS = 12
    }
}
