package com.zapix.tv

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.TextView

/** Lista de canales. Marca en azul el canal que se está reproduciendo. */
class ChannelAdapter(
    private val inflater: LayoutInflater,
    private val showNumber: Boolean
) : BaseAdapter() {

    var items: List<Channel> = emptyList()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    var playingUrl: String? = null
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun getCount() = items.size
    override fun getItem(position: Int): Any = items[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val row = convertView ?: inflater.inflate(android.R.layout.simple_list_item_2, parent, false)
        val c = items[position]
        val title = row.findViewById<TextView>(android.R.id.text1)
        val sub = row.findViewById<TextView>(android.R.id.text2)
        title.text = if (showNumber) "${position + 1}   ${c.name}" else c.name
        title.textSize = 20f
        title.setTextColor(if (c.url == playingUrl) 0xFF5AA2FF.toInt() else 0xFFFFFFFF.toInt())
        sub.text = c.group
        sub.textSize = 13f
        sub.setTextColor(0xFF9AA4B2.toInt())
        return row
    }
}

/** Lista de grupos (categorías) de la pestaña TV. */
class GroupAdapter(context: Context) :
    ArrayAdapter<String>(context, android.R.layout.simple_list_item_1) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val v = super.getView(position, convertView, parent) as TextView
        v.textSize = 20f
        v.setTextColor(0xFFFFFFFF.toInt())
        return v
    }
}
