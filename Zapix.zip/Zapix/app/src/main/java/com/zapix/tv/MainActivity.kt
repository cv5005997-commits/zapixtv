package com.zapix.tv

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.io.File

/**
 * Zapix: tres apartados (Inicio, TV, Ajustes) y dos modos de pantalla.
 *  - MENU: pestañas a la izquierda y vista previa del video a la derecha.
 *  - FULL: video a pantalla completa con cambio de canal (arriba/abajo, CH+/CH-, números).
 */
class MainActivity : Activity() {

    private enum class Mode { MENU, FULL }

    private lateinit var prefs: Prefs

    private lateinit var surface: SurfaceView
    private lateinit var menu: View
    private lateinit var info: TextView
    private lateinit var status: TextView
    private lateinit var tabs: Array<TextView>
    private lateinit var pages: Array<View>

    // Inicio
    private lateinit var btnContinue: Button
    private lateinit var tvStats: TextView
    private lateinit var listRecent: ListView

    // TV
    private lateinit var listGroups: ListView
    private lateinit var listChannels: ListView

    // Ajustes
    private lateinit var etUrl: EditText
    private lateinit var etUa: EditText
    private lateinit var btnBuffer: Button
    private lateinit var btnSave: Button

    private lateinit var channelAdapter: ChannelAdapter
    private lateinit var recentAdapter: ChannelAdapter
    private lateinit var groupAdapter: GroupAdapter

    private var engine: PlayerEngine? = null
    private var mode = Mode.MENU

    private var channels: List<Channel> = emptyList()   // toda la lista
    private var visible: List<Channel> = emptyList()    // la del grupo elegido en la pestaña TV
    private var groupKeys: List<String?> = emptyList()  // null = todos los canales
    private var recentChannels: List<Channel> = emptyList()
    private var current: Channel? = null

    private var bufferIndex = BufferPreset.DEFAULT_INDEX
    private var videoAspect = 16f / 9f
    private var numBuf = ""

    private val ui = Handler(Looper.getMainLooper())
    private val hideInfo = Runnable { info.visibility = View.GONE }
    private val hideStatus = Runnable { status.visibility = View.GONE }

    // Un canal entra en "vistos recientemente" solo si se mira 5 s (no al pasar zapeando)
    private val pushRecent = Runnable {
        current?.let {
            prefs.pushRecent(it.url)
            refreshHome()
        }
    }

    private val commitNumber = Runnable {
        val n = numBuf.toIntOrNull()
        numBuf = ""
        val base = zapBase()
        if (n != null && n in 1..base.size) {
            playChannel(base[n - 1])
        } else {
            showStatus("No existe ese canal", persistent = false)
            info.visibility = View.GONE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        prefs = Prefs(this)
        bufferIndex = prefs.bufferIndex

        surface = findViewById(R.id.surface)
        menu = findViewById(R.id.menu)
        info = findViewById(R.id.info)
        status = findViewById(R.id.status)
        tabs = arrayOf<TextView>(
            findViewById(R.id.tabHome), findViewById(R.id.tabTv), findViewById(R.id.tabSettings)
        )
        pages = arrayOf<View>(
            findViewById(R.id.pageHome), findViewById(R.id.pageTv), findViewById(R.id.pageSettings)
        )
        btnContinue = findViewById(R.id.btnContinue)
        tvStats = findViewById(R.id.tvStats)
        listRecent = findViewById(R.id.listRecent)
        listGroups = findViewById(R.id.listGroups)
        listChannels = findViewById(R.id.listChannels)
        etUrl = findViewById(R.id.etUrl)
        etUa = findViewById(R.id.etUa)
        btnBuffer = findViewById(R.id.btnBuffer)
        btnSave = findViewById(R.id.btnSave)

        channelAdapter = ChannelAdapter(layoutInflater, true)
        recentAdapter = ChannelAdapter(layoutInflater, false)
        groupAdapter = GroupAdapter(this)
        listChannels.adapter = channelAdapter
        listRecent.adapter = recentAdapter
        listGroups.adapter = groupAdapter

        setupTabs()
        setupHome()
        setupTv()
        setupSettings()

        applySurfaceLayout()

        if (prefs.playlistUrl.isBlank() && !cacheFile().exists()) {
            showTab(2)
            etUrl.requestFocus()
            showStatus("Pega la URL de tu lista M3U y toca Guardar", persistent = false)
        } else {
            showTab(0)
            btnContinue.requestFocus()
        }
        refreshHome()
        loadPlaylist()
    }

    override fun onStart() {
        super.onStart()
        createEngine()
        current?.let { engine?.play(it) }
    }

    override fun onStop() {
        super.onStop()
        // Soltar el reproductor al salir: en 1 GB de RAM cada MB cuenta
        engine?.release()
        engine = null
    }

    // ---------- Armado de las pantallas ----------

    private fun setupTabs() {
        tabs.forEachIndexed { i, tab ->
            // Al pasar por una pestaña con el control, se muestra su pantalla
            tab.setOnFocusChangeListener { _, hasFocus -> if (hasFocus) showTab(i) }
            tab.setOnClickListener {
                showTab(i)
                focusPage(i)
            }
        }
    }

    private fun setupHome() {
        btnContinue.setOnClickListener {
            val ch = current ?: lastChannel()
            if (ch != null) {
                if (ch != current) playChannel(ch)
                enterFull()
            }
        }
        listRecent.setOnItemClickListener { _, _, pos, _ ->
            recentChannels.getOrNull(pos)?.let {
                playChannel(it)
                enterFull()
            }
        }
    }

    private fun setupTv() {
        listGroups.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                applyGroup(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        listGroups.setOnItemClickListener { _, _, _, _ -> listChannels.requestFocus() }
        listChannels.setOnItemClickListener { _, _, pos, _ ->
            val ch = visible.getOrNull(pos) ?: return@setOnItemClickListener
            // Primer OK: vista previa. Segundo OK sobre el mismo canal: pantalla completa.
            if (ch == current) enterFull() else playChannel(ch)
        }
    }

    private fun setupSettings() {
        etUrl.setText(prefs.playlistUrl)
        etUa.setText(prefs.userAgent)
        updateBufferButton()
        btnBuffer.setOnClickListener {
            bufferIndex = (bufferIndex + 1) % BufferPreset.values().size
            prefs.bufferIndex = bufferIndex
            updateBufferButton()
            restartEngine()
        }
        btnSave.setOnClickListener {
            prefs.playlistUrl = etUrl.text.toString().trim()
            prefs.userAgent = etUa.text.toString().trim().ifEmpty { Prefs.DEFAULT_UA }
            restartEngine()
            loadPlaylist()
            Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateBufferButton() {
        btnBuffer.text = "Buffer: ${BufferPreset.fromIndex(bufferIndex).label}  (OK para cambiar)"
    }

    private fun showTab(index: Int) {
        pages.forEachIndexed { j, p -> p.visibility = if (j == index) View.VISIBLE else View.GONE }
        tabs.forEachIndexed { j, t -> t.isSelected = j == index }
    }

    private fun focusPage(index: Int) {
        when (index) {
            0 -> btnContinue.requestFocus()
            1 -> listGroups.requestFocus()
            else -> etUrl.requestFocus()
        }
    }

    // ---------- Reproducción ----------

    private fun createEngine() {
        engine = PlayerEngine(
            this,
            prefs.userAgent,
            BufferPreset.fromIndex(bufferIndex),
            { msg -> onEngineStatus(msg) },
            { aspect ->
                videoAspect = aspect
                applySurfaceLayout()
            }
        ).also { it.attach(surface) }
    }

    private fun restartEngine() {
        engine?.release()
        createEngine()
        current?.let { engine?.play(it) }
    }

    private fun playChannel(ch: Channel) {
        current = ch
        prefs.lastUrl = ch.url
        engine?.play(ch)
        channelAdapter.playingUrl = ch.url
        recentAdapter.playingUrl = ch.url
        ui.removeCallbacks(pushRecent)
        ui.postDelayed(pushRecent, 5000)
        refreshHome()
        showInfo(ch)
    }

    private fun lastChannel(): Channel? {
        val last = prefs.lastUrl
        return channels.firstOrNull { it.url == last } ?: channels.firstOrNull()
    }

    /** Lista sobre la que se cambia de canal: el grupo que se está mirando, o todos. */
    private fun zapBase(): List<Channel> {
        val cur = current
        return if (cur != null && visible.contains(cur)) visible else channels
    }

    private fun zap(delta: Int) {
        val base = zapBase()
        if (base.isEmpty()) return
        val cur = current
        val idx = if (cur != null) base.indexOf(cur).let { if (it < 0) 0 else it } else 0
        playChannel(base[(idx + delta + base.size) % base.size])
    }

    private fun typeDigit(d: Int) {
        numBuf = (numBuf + d).takeLast(4)
        info.text = "Canal  $numBuf"
        info.visibility = View.VISIBLE
        ui.removeCallbacks(hideInfo)
        ui.removeCallbacks(commitNumber)
        ui.postDelayed(commitNumber, 1500)
    }

    private fun showInfo(ch: Channel) {
        if (mode != Mode.FULL) return
        val n = zapBase().indexOf(ch) + 1
        val title = (if (n > 0) "$n   " else "") + ch.name
        info.text = if (ch.group.isNotEmpty()) "$title\n${ch.group}" else title
        info.visibility = View.VISIBLE
        ui.removeCallbacks(hideInfo)
        ui.postDelayed(hideInfo, 3500)
    }

    private fun onEngineStatus(msg: String?) {
        if (msg != null) {
            showStatus(msg, persistent = true)
        } else {
            ui.removeCallbacks(hideStatus)
            ui.postDelayed(hideStatus, 1500)
        }
    }

    private fun showStatus(text: String, persistent: Boolean) {
        status.text = text
        status.visibility = View.VISIBLE
        ui.removeCallbacks(hideStatus)
        if (!persistent) ui.postDelayed(hideStatus, 4000)
    }

    // ---------- Modos de pantalla ----------

    private fun enterFull() {
        mode = Mode.FULL
        menu.visibility = View.GONE
        applySurfaceLayout()
        current?.let { showInfo(it) }
    }

    private fun exitFull() {
        mode = Mode.MENU
        numBuf = ""
        ui.removeCallbacks(commitNumber)
        ui.removeCallbacks(hideInfo)
        info.visibility = View.GONE
        menu.visibility = View.VISIBLE
        applySurfaceLayout()
        showTab(1)
        listChannels.requestFocus()
        val cur = current
        val idx = if (cur != null) visible.indexOf(cur) else -1
        if (idx >= 0) listChannels.setSelection(idx)
    }

    /** Video a pantalla completa o en la vista previa de la derecha, siempre con su proporción real. */
    private fun applySurfaceLayout() {
        val dm = resources.displayMetrics
        val boxW: Int
        val boxH: Int
        val boxTop: Int
        val boxEnd: Int
        if (mode == Mode.FULL) {
            boxW = dm.widthPixels
            boxH = dm.heightPixels
            boxTop = 0
            boxEnd = 0
        } else {
            boxW = (dm.widthPixels * 0.42f).toInt()
            boxH = boxW * 9 / 16
            boxTop = (88 * dm.density).toInt()
            boxEnd = (32 * dm.density).toInt()
        }
        var w = boxW
        var h = (w / videoAspect).toInt()
        if (h > boxH) {
            h = boxH
            w = (h * videoAspect).toInt()
        }
        val lp = FrameLayout.LayoutParams(w, h)
        lp.gravity = Gravity.TOP or Gravity.END
        lp.topMargin = boxTop + (boxH - h) / 2
        lp.marginEnd = boxEnd + (boxW - w) / 2
        surface.layoutParams = lp
    }

    // ---------- Lista de canales ----------

    private fun cacheFile() = File(filesDir, "playlist.m3u")

    private fun loadPlaylist() {
        val url = prefs.playlistUrl
        val ua = prefs.userAgent
        val cache = cacheFile()
        Thread {
            // 1) Mostrar al instante la última lista guardada
            if (cache.exists()) {
                runCatching { PlaylistLoader.parse(cache) }
                    .onSuccess { l -> runOnUiThread { if (!isFinishing) setChannels(l) } }
            }
            // 2) Actualizarla desde internet sin cortar lo que se está viendo
            if (url.isNotBlank()) {
                try {
                    PlaylistLoader.download(url, ua, cache)
                    val l = PlaylistLoader.parse(cache)
                    runOnUiThread { if (!isFinishing) setChannels(l) }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(
                            this, "No se pudo actualizar la lista: ${e.message}", Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }.start()
    }

    private fun setChannels(newList: List<Channel>) {
        val prevKey = groupKeys.getOrNull(listGroups.selectedItemPosition)
        channels = newList

        val counts = LinkedHashMap<String, Int>()
        for (c in newList) {
            val g = c.group.ifEmpty { NO_GROUP }
            counts[g] = (counts[g] ?: 0) + 1
        }
        groupKeys = listOf<String?>(null) + counts.keys

        groupAdapter.setNotifyOnChange(false)
        groupAdapter.clear()
        groupAdapter.add("Todos (${newList.size})")
        for ((g, n) in counts) groupAdapter.add("$g ($n)")
        groupAdapter.notifyDataSetChanged()

        val idx = groupKeys.indexOf(prevKey).let { if (it < 0) 0 else it }
        listGroups.setSelection(idx)
        applyGroup(idx)

        if (newList.isEmpty()) {
            showStatus("La lista no tiene canales", persistent = false)
        } else if (current == null) {
            lastChannel()?.let { playChannel(it) } // arranca en la vista previa
        }
        refreshHome()
    }

    private fun applyGroup(pos: Int) {
        val key = groupKeys.getOrNull(pos)
        visible = if (key == null) channels else channels.filter { it.group.ifEmpty { NO_GROUP } == key }
        channelAdapter.items = visible
    }

    private fun refreshHome() {
        recentChannels = prefs.recents.mapNotNull { u -> channels.firstOrNull { it.url == u } }
        recentAdapter.items = recentChannels
        val cur = current
        btnContinue.text = if (cur != null) "Continuar: ${cur.name}" else "Sin canal todavía"
        tvStats.text = "${channels.size} canales  ·  ${maxOf(groupKeys.size - 1, 0)} grupos"
    }

    // ---------- Control remoto ----------

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (mode == Mode.FULL) {
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> zap(-1)
                KeyEvent.KEYCODE_DPAD_DOWN -> zap(1)
                KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> zap(1)
                KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> zap(-1)
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> current?.let { showInfo(it) }
                KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_BACK -> exitFull()
                in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> typeDigit(keyCode - KeyEvent.KEYCODE_0)
                else -> return super.onKeyDown(keyCode, event)
            }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private companion object {
        const val NO_GROUP = "Sin grupo"
    }
}
