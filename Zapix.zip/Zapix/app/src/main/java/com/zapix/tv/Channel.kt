package com.zapix.tv

data class Channel(val name: String, val group: String, val url: String)
