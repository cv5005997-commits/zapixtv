package com.zapix.tv

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SetItem(val title: String, val value: () -> String, val action: () -> Unit)

/**
 * Zapix: barra lateral (Buscar, Inicio, TV, Ajustes) y dos modos de pantalla.
 *  - MENU: pantallas con el video en una vista previa (pestaña TV).
 *  - FULL: video a pantalla completa con cambio de canal (arriba/abajo, CH+/CH-, números).
 */
class MainActivity : Activity() {

    private enum class Mode { MENU, FULL }

    private lateinit var settings: Settings
    private lateinit var store: PlaylistStore
    private lateinit var epg: EpgDb
    private lateinit var logos: LogoLoader

    private lateinit var root: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var menu: View
    private lateinit var sidebar: View
    private lateinit var info: TextView
    private lateinit var status: TextView
    private lateinit var navs: Array<View>
    private lateinit var pages: Array<View>

    // Inicio
    private lateinit var homeStats: TextView
    private lateinit var btnContinue: Button
    private lateinit var listRecent: ListView

    // TV
    private lateinit var listGroups: ListView
    private lateinit var listChannels: ChannelListView
    private lateinit var previewBox: View
    private lateinit var epgHeader: EpgHeaderView
    private lateinit var pvTitle: TextView
    private lateinit var pvTime: TextView
    private lateinit var pvLeft: TextView
    private lateinit var pvDesc: TextView
    private lateinit var pvFav: TextView
    private lateinit var pvProgress: ProgressBar

    // Buscar
    private lateinit var etSearch: EditText
    private lateinit var listSearch: ListView

    // Ajustes
    private lateinit var listSetCats: ListView
    private lateinit var listSetItems: ListView

    private lateinit var recentAdapter: ChannelListAdapter
    private lateinit var searchAdapter: ChannelListAdapter
    private lateinit var groupAdapter: GroupAdapter
    private lateinit var catAdapter: GroupAdapter
    private lateinit var epgAdapter: EpgRowAdapter
    private val setAdapter = SetAdapter()
    private val win = EpgWindow()

    private var engine: PlayerEngine? = null
    private var mode = Mode.MENU
    private var tab = TAB_TV

    private var channels: List<Channel> = emptyList()
    private var shown: List<Channel> = emptyList()
    private var groupKeys: List<String?> = emptyList()
    private var current: Channel? = null
    private var playingUrl = ""
    private var playToken = 0
    private var loadGen = 0
    private var firstLoad = true

    private var videoAspect = 16f / 9f
    private var numBuf = ""
    private var unlocked = false
    private var longHandled = false

    private var setItems: List<SetItem> = emptyList()
    private var setCat = 0

    private var listEpgUrl = ""
    private var epgBusy = false
    private var epgFrom = 0L
    private var epgTo = 0L
    private val epgCache = HashMap<String, List<Program>>()
    private val stalker = HashMap<String, StalkerClient>()
    private val hourFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    private val ui = Handler(Looper.getMainLooper())
    private val hideInfo = Runnable { info.visibility = View.GONE }
    private val hideStatus = Runnable { status.visibility = View.GONE }

    // Un canal entra en "vistos recientemente" solo si se mira 5 s (no al pasar zapeando)
    private val pushRecent = Runnable {
        current?.let {
            settings.pushRecent(it.url)
            refreshHome()
        }
    }

    private val commitNumber = Runnable {
        val n = numBuf.toIntOrNull()
        numBuf = ""
        val ch = if (n != null) channels.firstOrNull { it.number == n } else null
        if (ch != null) {
            playChannel(ch)
        } else {
            info.visibility = View.GONE
            showStatus("No existe ese canal", false)
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            ui.postDelayed(this, 30_000)
        }
    }

    // =====================================================================
    // Ciclo de vida
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        settings = Settings(this)
        store = PlaylistStore(this, settings)
        epg = EpgDb(this)
        logos = LogoLoader(this)

        root = findViewById(R.id.root)
        surface = findViewById(R.id.surface)
        menu = findViewById(R.id.menu)
        sidebar = findViewById(R.id.sidebar)
        info = findViewById(R.id.info)
        status = findViewById(R.id.status)
        navs = arrayOf(
            findViewById(R.id.navSearch), findViewById(R.id.navHome),
            findViewById(R.id.navTv), findViewById(R.id.navSettings)
        )
        pages = arrayOf(
            findViewById(R.id.pageSearch), findViewById(R.id.pageHome),
            findViewById(R.id.pageTv), findViewById(R.id.pageSettings)
        )
        homeStats = findViewById(R.id.homeStats)
        btnContinue = findViewById(R.id.btnContinue)
        listRecent = findViewById(R.id.listRecent)
        listGroups = findViewById(R.id.listGroups)
        listChannels = findViewById(R.id.listChannels)
        previewBox = findViewById(R.id.previewBox)
        epgHeader = findViewById(R.id.epgHeader)
        pvTitle = findViewById(R.id.pvTitle)
        pvTime = findViewById(R.id.pvTime)
        pvLeft = findViewById(R.id.pvLeft)
        pvDesc = findViewById(R.id.pvDesc)
        pvFav = findViewById(R.id.pvFav)
        pvProgress = findViewById(R.id.pvProgress)
        etSearch = findViewById(R.id.etSearch)
        listSearch = findViewById(R.id.listSearch)
        listSetCats = findViewById(R.id.listSetCats)
        listSetItems = findViewById(R.id.listSetItems)

        recentAdapter = ChannelListAdapter(layoutInflater, logos, settings)
        searchAdapter = ChannelListAdapter(layoutInflater, logos, settings)
        groupAdapter = GroupAdapter(this)
        catAdapter = GroupAdapter(this)
        epgAdapter = EpgRowAdapter(layoutInflater, logos, settings, win) { c -> programsFor(c) }

        listRecent.adapter = recentAdapter
        listSearch.adapter = searchAdapter
        listGroups.adapter = groupAdapter
        listChannels.adapter = epgAdapter
        listSetCats.adapter = catAdapter
        listSetItems.adapter = setAdapter

        catAdapter.addAll(
            "General", "Listas", "EPG", "Apariencia", "Reproducción",
            "Mando a distancia", "Control parental", "Otro"
        )
        applyTextScale()

        win.resetToNow(System.currentTimeMillis())

        setupNav()
        setupHome()
        setupTv()
        setupSearch()
        setupSettingsPage()

        previewBox.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (mode == Mode.MENU && tab == TAB_TV) applySurfaceLayout()
        }

        if (store.all().isEmpty()) {
            showTab(TAB_SET)
            listSetCats.setSelection(1)
            selectCat(1)
            listSetCats.requestFocus()
            toast("Añade tu lista: Listas > Añadir lista")
        } else {
            showTab(if (settings.startMode == 0) TAB_HOME else TAB_TV)
            focusPage(tab)
        }
        refreshHome()
        loadPlaylist(false)
    }

    override fun onStart() {
        super.onStart()
        createEngine()
        if (playingUrl.isNotEmpty()) engine?.play(playingUrl) else current?.let { resolveAndPlay(it, playToken) }
        ui.postDelayed(ticker, 30_000)
    }

    override fun onStop() {
        super.onStop()
        ui.removeCallbacks(ticker)
        // Soltar el reproductor al salir: en 1 GB de RAM cada MB cuenta
        engine?.release()
        engine = null
    }

    override fun onDestroy() {
        super.onDestroy()
        epg.close()
    }

    // =====================================================================
    // Armado de las pantallas
    // =====================================================================

    private fun setupNav() {
        navs.forEachIndexed { i, v ->
            // Al pasar por un ícono con el control, se muestra su pantalla
            v.setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus && !(i == TAB_SET && settingsLocked())) showTab(i)
            }
            v.setOnClickListener {
                if (i == TAB_SET && settingsLocked()) {
                    Ui.pin(this, "PIN") { p ->
                        if (p == settings.pin) {
                            unlocked = true
                            showTab(i)
                            focusPage(i)
                        } else {
                            toast("PIN incorrecto")
                        }
                    }
                } else {
                    showTab(i)
                    focusPage(i)
                }
            }
        }
    }

    private fun setupHome() {
        btnContinue.setOnClickListener {
            val ch = current ?: lastChannel()
            if (ch != null) {
                if (ch.url != current?.url) playChannel(ch)
                enterFull()
            }
        }
        listRecent.setOnItemClickListener { _, _, pos, _ ->
            (recentAdapter.getItem(pos) as? Channel)?.let {
                playChannel(it)
                enterFull()
            }
        }
    }

    private fun setupTv() {
        listGroups.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                applyGroup(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        listGroups.setOnItemClickListener { _, _, pos, _ ->
            applyGroup(pos) // con el dedo la selección no cambia sola
            if (groupIsLocked(pos)) {
                Ui.pin(this, "Grupo bloqueado: PIN") { p ->
                    if (p == settings.pin) {
                        unlocked = true
                        applyGroup(pos)
                        listChannels.requestFocus()
                    } else {
                        toast("PIN incorrecto")
                    }
                }
            } else {
                listChannels.requestFocus()
            }
        }

        listChannels.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                epgAdapter.selRow = position
                epgAdapter.selProg = shown.getOrNull(position)?.let { nowProgIndex(it) } ?: -1
                epgAdapter.notifyDataSetChanged()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        listChannels.setOnItemClickListener { _, _, pos, _ ->
            val ch = shown.getOrNull(pos) ?: return@setOnItemClickListener
            // Primer OK: vista previa. Segundo OK sobre el mismo canal: pantalla completa.
            if (ch.url == current?.url) enterFull() else playChannel(ch)
        }
        listChannels.setOnItemLongClickListener { _, _, pos, _ ->
            shown.getOrNull(pos)?.let { toggleFavorite(it) }
            true
        }
        listChannels.onLeft = { moveProgram(-1) }
        listChannels.onRight = { moveProgram(1) }
    }

    private fun setupSearch() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString()?.trim()?.lowercase() ?: ""
                searchAdapter.items = if (q.isEmpty()) {
                    emptyList()
                } else {
                    channels.filter { it.name.lowercase().contains(q) && !isLocked(it) }.take(150)
                }
            }
        })
        listSearch.setOnItemClickListener { _, _, pos, _ ->
            (searchAdapter.getItem(pos) as? Channel)?.let {
                playChannel(it)
                enterFull()
            }
        }
    }

    private fun setupSettingsPage() {
        listSetCats.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectCat(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        // Con el dedo la selección no cambia sola: hay que mostrar la categoría al tocarla
        listSetCats.setOnItemClickListener { _, _, pos, _ ->
            selectCat(pos)
            listSetItems.requestFocus()
        }
        listSetItems.setOnItemClickListener { _, _, pos, _ -> setItems.getOrNull(pos)?.action?.invoke() }
        selectCat(0)
    }

    private fun selectCat(pos: Int) {
        setCat = pos
        catAdapter.selected = pos
        catAdapter.notifyDataSetChanged()
        refreshSet()
    }

    private fun showTab(index: Int) {
        tab = index
        pages.forEachIndexed { j, p -> p.visibility = if (j == index) View.VISIBLE else View.GONE }
        navs.forEachIndexed { j, v -> v.isSelected = j == index }
        surface.visibility = if (mode == Mode.FULL || index == TAB_TV) View.VISIBLE else View.INVISIBLE
        when (index) {
            TAB_TV -> {
                applySurfaceLayout()
                refreshGuide()
            }
            TAB_HOME -> refreshHome()
        }
    }

    private fun focusPage(index: Int) {
        when (index) {
            TAB_SEARCH -> etSearch.requestFocus()
            TAB_HOME -> btnContinue.requestFocus()
            TAB_TV -> listChannels.requestFocus()
            else -> listSetCats.requestFocus()
        }
    }

    private fun settingsLocked() = settings.lockSettings && settings.pin.isNotEmpty() && !unlocked

    // =====================================================================
    // Reproducción
    // =====================================================================

    private fun createEngine() {
        val cfg = EngineConfig(
            settings.userAgent,
            BufferPreset.fromIndex(settings.bufferIndex),
            settings.decoderMode,
            settings.maxHeight,
            settings.timeoutSec * 1000,
            settings.autoRetry
        )
        engine = PlayerEngine(
            this, cfg,
            { msg -> onEngineStatus(msg) },
            { aspect ->
                videoAspect = aspect
                applySurfaceLayout()
            }
        ).also { it.attach(surface) }
    }

    private fun restartEngine() {
        engine?.release()
        createEngine()
        if (playingUrl.isNotEmpty()) engine?.play(playingUrl)
    }

    private fun playChannel(ch: Channel) {
        current = ch
        settings.lastUrl = ch.url
        playToken++
        playingUrl = ""
        epgAdapter.playingUrl = ch.url
        recentAdapter.playingUrl = ch.url
        searchAdapter.playingUrl = ch.url
        ui.removeCallbacks(pushRecent)
        ui.postDelayed(pushRecent, 5000)
        resolveAndPlay(ch, playToken)
        updatePreview()
        showInfo(ch)
    }

    private fun startPlayback(url: String) {
        playingUrl = url
        engine?.play(url)
    }

    /** Canales normales se reproducen directo; los de Portal Stalker piden primero su enlace real. */
    private fun resolveAndPlay(ch: Channel, token: Int) {
        if (!ch.url.startsWith("stalker://")) {
            startPlayback(ch.url)
            return
        }
        val rest = ch.url.removePrefix("stalker://")
        val id = rest.substringBefore('/')
        val cmd = Uri.decode(rest.substringAfter('/'))
        val src = store.all().firstOrNull { it.id == id }
        if (src == null) {
            showStatus("No se encontró la lista de este canal", false)
            return
        }
        showStatus("Conectando…", true)
        val timeout = settings.timeoutSec * 1000
        Thread {
            try {
                val client = synchronized(stalker) {
                    stalker.getOrPut(id) { StalkerClient(src.a, src.b, timeout) }
                }
                val link = client.createLink(cmd)
                runOnUiThread {
                    if (token == playToken && !isFinishing) {
                        startPlayback(link)
                        onEngineStatus(null)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { if (token == playToken) showStatus("No se pudo abrir el canal", false) }
            }
        }.start()
    }

    private fun lastChannel(): Channel? =
        channels.firstOrNull { it.url == settings.lastUrl } ?: channels.firstOrNull()

    private fun lockedSet(): Set<String> = if (settings.pin.isEmpty()) emptySet() else settings.lockedGroups()

    private fun isLocked(c: Channel): Boolean =
        !unlocked && lockedSet().contains(c.group.ifEmpty { NO_GROUP })

    /** Lista sobre la que se cambia de canal: el grupo que se está mirando, o todos. */
    private fun zapBase(): List<Channel> {
        val cur = current
        val base = if (settings.zapInGroup && cur != null && shown.any { it.url == cur.url }) shown else channels
        return if (unlocked || lockedSet().isEmpty()) base else base.filter { !isLocked(it) }
    }

    private fun zap(delta: Int) {
        val base = zapBase()
        if (base.isEmpty()) return
        val cur = current
        val idx = if (cur != null) base.indexOfFirst { it.url == cur.url }.let { if (it < 0) 0 else it } else 0
        playChannel(base[(idx + delta + base.size) % base.size])
    }

    private fun typeDigit(d: Int) {
        numBuf = (numBuf + d).takeLast(4)
        info.text = "Canal  $numBuf"
        info.visibility = View.VISIBLE
        ui.removeCallbacks(hideInfo)
        ui.removeCallbacks(commitNumber)
        ui.postDelayed(commitNumber, 1500)
    }

    private fun showInfo(ch: Channel) {
        if (mode != Mode.FULL) return
        val prog = if (ch.epgId.isNotEmpty()) epg.current(ch.epgId, System.currentTimeMillis(), offsetMs()) else null
        val head = "${ch.number}   ${ch.name}"
        info.text = when {
            prog != null -> "$head\n${prog.title}"
            ch.group.isNotEmpty() -> "$head\n${ch.group}"
            else -> head
        }
        info.visibility = View.VISIBLE
        ui.removeCallbacks(hideInfo)
        ui.postDelayed(hideInfo, settings.bannerSeconds * 1000L)
    }

    private fun toggleFavorite(ch: Channel) {
        val on = settings.toggleFavorite(ch.url)
        toast(if (on) "Agregado a favoritos" else "Quitado de favoritos")
        updatePreview()
        if (groupKeys.getOrNull(listGroups.selectedItemPosition) == FAV) applyGroup(listGroups.selectedItemPosition)
    }

    private fun onEngineStatus(msg: String?) {
        if (msg != null) {
            showStatus(msg, true)
        } else {
            ui.removeCallbacks(hideStatus)
            ui.postDelayed(hideStatus, 1500)
        }
    }

    private fun showStatus(text: String, persistent: Boolean) {
        status.text = text
        status.visibility = View.VISIBLE
        ui.removeCallbacks(hideStatus)
        if (!persistent) ui.postDelayed(hideStatus, 4000)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // =====================================================================
    // Modos de pantalla
    // =====================================================================

    private fun enterFull() {
        mode = Mode.FULL
        menu.visibility = View.GONE
        surface.visibility = View.VISIBLE
        applySurfaceLayout()
        current?.let { showInfo(it) }
    }

    private fun exitFull() {
        mode = Mode.MENU
        numBuf = ""
        ui.removeCallbacks(commitNumber)
        ui.removeCallbacks(hideInfo)
        info.visibility = View.GONE
        menu.visibility = View.VISIBLE
        showTab(TAB_TV)
        listChannels.requestFocus()
        val cur = current
        val idx = if (cur != null) shown.indexOfFirst { it.url == cur.url } else -1
        if (idx >= 0) listChannels.setSelection(idx)
    }

    /** Video a pantalla completa o en la vista previa, respetando la relación de aspecto elegida. */
    private fun applySurfaceLayout() {
        val dm = resources.displayMetrics
        val boxL: Int
        val boxT: Int
        val boxW: Int
        val boxH: Int
        if (mode == Mode.FULL) {
            boxL = 0
            boxT = 0
            boxW = dm.widthPixels
            boxH = dm.heightPixels
        } else {
            if (previewBox.width == 0) return
            val a = IntArray(2)
            val b = IntArray(2)
            previewBox.getLocationInWindow(a)
            root.getLocationInWindow(b)
            boxL = a[0] - b[0]
            boxT = a[1] - b[1]
            boxW = previewBox.width
            boxH = previewBox.height
        }
        val asp = when (settings.aspectMode) {
            1 -> 16f / 9f
            2 -> 4f / 3f
            else -> videoAspect
        }
        var w = boxW
        var h = boxH
        when {
            settings.aspectMode == 3 -> Unit // estirar: ocupa todo el cuadro
            settings.aspectMode == 4 && mode == Mode.FULL -> { // zoom: llena y recorta
                w = maxOf(boxW, (boxH * asp).toInt())
                h = (w / asp).toInt()
                if (h < boxH) {
                    h = boxH
                    w = (h * asp).toInt()
                }
            }
            else -> { // ajustar sin deformar
                w = boxW
                h = (w / asp).toInt()
                if (h > boxH) {
                    h = boxH
                    w = (h * asp).toInt()
                }
            }
        }
        val lp = FrameLayout.LayoutParams(w, h)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.leftMargin = boxL + (boxW - w) / 2
        lp.topMargin = boxT + (boxH - h) / 2
        surface.layoutParams = lp
    }

    // =====================================================================
    // Lista de canales
    // =====================================================================

    private fun xtreamBase(s: Source): String {
        var v = s.a.trim()
        if (!v.startsWith("http")) v = "http://$v"
        return v.trimEnd('/')
    }

    private fun xtreamUrl(s: Source) =
        "${xtreamBase(s)}/get.php?username=${Uri.encode(s.b)}&password=${Uri.encode(s.c)}&type=m3u_plus&output=ts"

    private fun xtreamEpgUrl(s: Source) =
        "${xtreamBase(s)}/xmltv.php?username=${Uri.encode(s.b)}&password=${Uri.encode(s.c)}"

    private fun loadPlaylist(forceDownload: Boolean) {
        val src = store.active()
        if (src == null) {
            setChannels(emptyList(), "", null)
            return
        }
        val cache = store.cacheFile(src.id)
        val sortAz = settings.sortAz
        val timeout = settings.timeoutSec * 1000
        val ua = settings.userAgent
        val gen = ++loadGen
        Thread {
            // 1) Mostrar al instante la última lista guardada
            if (cache.exists()) {
                try {
                    val r = M3u.parse(cache, sortAz)
                    runOnUiThread { if (gen == loadGen && !isFinishing) setChannels(r.channels, r.epgUrl, src) }
                } catch (e: Exception) {
                    // archivo dañado: se vuelve a bajar
                }
            }
            // 2) Actualizarla desde internet sin cortar lo que se está viendo
            if (forceDownload || settings.refreshOnOpen || !cache.exists()) {
                try {
                    when (src.type) {
                        Source.M3U -> Http.download(src.a, ua, cache, timeout)
                        Source.XTREAM -> Http.download(xtreamUrl(src), ua, cache, timeout)
                        else -> StalkerClient(src.a, src.b, timeout).downloadChannels(src.id, cache)
                    }
                    val r = M3u.parse(cache, sortAz)
                    runOnUiThread { if (gen == loadGen && !isFinishing) setChannels(r.channels, r.epgUrl, src) }
                } catch (e: Exception) {
                    runOnUiThread {
                        if (!isFinishing) toast("No se pudo actualizar la lista: ${e.message}")
                    }
                }
            }
        }.start()
    }

    private fun setChannels(newList: List<Channel>, epgFromList: String, src: Source?) {
        channels = newList
        listEpgUrl = if (src?.type == Source.XTREAM) xtreamEpgUrl(src) else epgFromList

        val prevKey = groupKeys.getOrNull(listGroups.selectedItemPosition)
        val counts = LinkedHashMap<String, Int>()
        for (c in newList) {
            val g = c.group.ifEmpty { NO_GROUP }
            counts[g] = (counts[g] ?: 0) + 1
        }
        groupKeys = listOf<String?>(FAV, null) + counts.keys

        groupAdapter.setNotifyOnChange(false)
        groupAdapter.clear()
        groupAdapter.add("Favoritos")
        groupAdapter.add("Todos los canales")
        for ((g, n) in counts) groupAdapter.add("$g ($n)")
        groupAdapter.notifyDataSetChanged()

        val idx = groupKeys.indexOf(prevKey).let { if (it < 0) 1 else it }
        listGroups.setSelection(idx)
        applyGroup(idx)

        val cur = current
        if (cur != null) {
            current = newList.firstOrNull { it.url == cur.url } ?: cur
        } else if (newList.isNotEmpty()) {
            lastChannel()?.let { playChannel(it) }
            if (firstLoad && settings.startMode == 2) enterFull()
        }
        firstLoad = false
        refreshHome()
        refreshGuide()
        maybeRefreshEpg()
    }

    private fun groupIsLocked(pos: Int): Boolean {
        val key = groupKeys.getOrNull(pos) ?: return false
        return key != FAV && !unlocked && lockedSet().contains(key)
    }

    private fun applyGroup(pos: Int) {
        val key = groupKeys.getOrNull(pos)
        shown = when {
            groupIsLocked(pos) -> emptyList()
            key == FAV -> channels.filter { settings.isFavorite(it.url) }
            key == null -> channels
            else -> channels.filter { it.group.ifEmpty { NO_GROUP } == key }
        }
        epgAdapter.items = shown
        epgAdapter.selRow = -1
        epgAdapter.selProg = -1
        groupAdapter.selected = pos
        groupAdapter.notifyDataSetChanged()
    }

    // Con el dedo en pantalla completa: tocar muestra el cartel; deslizar arriba/abajo cambia de canal
    private var touchY = 0f

    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        if (mode == Mode.FULL) {
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> touchY = event.y
                android.view.MotionEvent.ACTION_UP -> {
                    val dy = event.y - touchY
                    if (dy < -120f) zap(1) else if (dy > 120f) zap(-1) else current?.let { showInfo(it) }
                }
            }
            return true
        }
        return super.onTouchEvent(event)
    }

    private fun refreshHome() {
        val recents = settings.recents().mapNotNull { u -> channels.firstOrNull { it.url == u } }
        recentAdapter.items = recents
        val cur = current
        btnContinue.text = if (cur != null) "Continuar: ${cur.name}" else "Sin canal todavía"
        homeStats.text = "${channels.size} canales  ·  ${maxOf(groupKeys.size - 2, 0)} grupos"
    }

    // =====================================================================
    // Guía de programación (EPG)
    // =====================================================================

    private fun offsetMs() = settings.epgOffsetHours * 3_600_000L

    private fun programsFor(c: Channel): List<Program> {
        if (c.epgId.isEmpty()) return emptyList()
        return epgCache.getOrPut(c.epgId) { epg.programs(c.epgId, epgFrom, epgTo, offsetMs()) }
    }

    private fun nowProgIndex(c: Channel): Int {
        val now = System.currentTimeMillis()
        val progs = programsFor(c)
        val i = progs.indexOfFirst { it.start <= now && it.stop > now }
        return if (i >= 0) i else progs.indexOfFirst { it.stop > win.startMs }
    }

    private fun refreshGuide() {
        val now = System.currentTimeMillis()
        epgFrom = now - 3 * EpgDb.HOUR
        epgTo = now + 40 * EpgDb.HOUR
        epgCache.clear()
        epgHeader.windowStart = win.startMs
        epgHeader.windowMinutes = win.minutes
        epgHeader.leftOffsetPx = (258 * resources.displayMetrics.density).toInt()
        epgHeader.textFactor = settings.textFactor()
        epgHeader.invalidate()
        epgAdapter.notifyDataSetChanged()
        updatePreview()
    }

    /** Mueve la selección entre los programas del canal elegido. Devuelve false si no hay nada que mover. */
    private fun moveProgram(delta: Int): Boolean {
        val row = epgAdapter.selRow
        val ch = shown.getOrNull(row) ?: return false
        val progs = programsFor(ch)
        if (progs.isEmpty()) return false
        val next = epgAdapter.selProg + delta
        if (next < 0) return false
        if (next >= progs.size) return true
        epgAdapter.selProg = next
        val p = progs[next]
        if (p.start >= win.endMs()) {
            win.startMs = (p.start / 1_800_000L) * 1_800_000L - 1_800_000L
        } else if (p.stop <= win.startMs) {
            win.startMs = (p.start / 1_800_000L) * 1_800_000L
        }
        epgHeader.windowStart = win.startMs
        epgHeader.invalidate()
        epgAdapter.notifyDataSetChanged()
        return true
    }

    private fun updatePreview() {
        val c = current
        if (c == null) {
            pvTitle.text = ""
            pvTime.text = ""
            pvLeft.text = ""
            pvDesc.text = ""
            pvFav.text = ""
            pvProgress.progress = 0
            return
        }
        val now = System.currentTimeMillis()
        val p = if (c.epgId.isNotEmpty()) epg.current(c.epgId, now, offsetMs()) else null
        if (p != null) {
            pvTitle.text = p.title
            pvTime.text = "${hourFmt.format(Date(p.start))} — ${hourFmt.format(Date(p.stop))}"
            val total = (p.stop - p.start).coerceAtLeast(1L)
            pvProgress.progress = ((now - p.start) * 100 / total).toInt().coerceIn(0, 100)
            pvLeft.text = "${((p.stop - now) / 60_000L).coerceAtLeast(0)} min"
            pvDesc.text = p.desc
        } else {
            pvTitle.text = "Sin información"
            pvTime.text = c.name
            pvProgress.progress = 0
            pvLeft.text = ""
            pvDesc.text = ""
        }
        pvFav.text = if (settings.isFavorite(c.url)) "★" else "☆"
    }

    private fun maybeRefreshEpg() = refreshEpg(false)

    private fun currentEpgUrl(): String =
        if (settings.epgUrl.isNotBlank()) settings.epgUrl.trim() else listEpgUrl

    private fun refreshEpg(force: Boolean) {
        val url = currentEpgUrl()
        if (url.isBlank()) {
            if (force) toast("Esta lista no trae guía: pega una URL en Ajustes > EPG")
            return
        }
        val age = System.currentTimeMillis() - settings.epgLastUpdate
        if (!force && (settings.epgHours == 0 || age < settings.epgHours * EpgDb.HOUR)) return
        if (epgBusy) return
        epgBusy = true
        if (force) toast("Actualizando guía…")
        val wanted = channels.map { it.epgId }.filter { it.isNotEmpty() }.toHashSet()
        val ua = settings.userAgent
        val timeout = settings.timeoutSec * 1000
        Thread {
            try {
                val n = epg.refresh(url, ua, timeout, wanted, cacheDir)
                settings.epgLastUpdate = System.currentTimeMillis()
                runOnUiThread {
                    epgBusy = false
                    if (!isFinishing) {
                        refreshGuide()
                        refreshSet()
                        if (force) toast("Guía actualizada: $n programas")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    epgBusy = false
                    if (force && !isFinishing) toast("No se pudo actualizar la guía: ${e.message}")
                }
            }
        }.start()
    }

    private fun tick() {
        val now = System.currentTimeMillis()
        if (now > win.startMs + 150 * 60_000L) {
            win.resetToNow(now)
            epgHeader.windowStart = win.startMs
        }
        epgHeader.invalidate()
        epgAdapter.notifyDataSetChanged()
        updatePreview()
    }

    // =====================================================================
    // Ajustes
    // =====================================================================

    private inner class SetAdapter : BaseAdapter() {
        override fun getCount() = setItems.size
        override fun getItem(position: Int): Any = setItems[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = convertView ?: layoutInflater.inflate(R.layout.row_setting, parent, false)
            val it = setItems[position]
            val f = settings.textFactor()
            val title = row.findViewById<TextView>(R.id.setTitle)
            val value = row.findViewById<TextView>(R.id.setValue)
            title.text = it.title
            title.textSize = 19f * f
            val v = it.value()
            value.text = v
            value.textSize = 14f * f
            value.visibility = if (v.isEmpty()) View.GONE else View.VISIBLE
            return row
        }
    }

    private fun refreshSet() {
        setItems = buildSettings(setCat)
        setAdapter.notifyDataSetChanged()
    }

    private fun toggle(title: String, get: () -> Boolean, set: (Boolean) -> Unit, after: () -> Unit = {}) =
        SetItem(title, { if (get()) "Activado" else "Desactivado" }) {
            set(!get())
            after()
            refreshSet()
        }

    private fun pick(
        title: String,
        opts: List<String>,
        get: () -> Int,
        set: (Int) -> Unit,
        after: () -> Unit = {}
    ) = SetItem(title, { opts.getOrElse(get()) { "" } }) {
        Ui.choice(this, title, opts, get()) { i ->
            set(i)
            after()
            refreshSet()
        }
    }

    private fun buildSettings(cat: Int): List<SetItem> = when (cat) {
        0 -> generalSettings()
        1 -> listSettings()
        2 -> epgSettings()
        3 -> appearanceSettings()
        4 -> playbackSettings()
        5 -> remoteSettings()
        6 -> parentalSettings()
        else -> otherSettings()
    }

    private fun generalSettings(): List<SetItem> {
        val seconds = listOf(2, 4, 6, 10)
        return listOf(
            pick("Pantalla de inicio", listOf("Inicio", "TV", "Último canal a pantalla completa"),
                { settings.startMode }, { settings.startMode = it }),
            pick("Duración del cartel del canal", seconds.map { "$it segundos" },
                { seconds.indexOf(settings.bannerSeconds).let { i -> if (i < 0) 1 else i } },
                { settings.bannerSeconds = seconds[it] }),
            toggle("Ordenar canales de la A a la Z", { settings.sortAz }, { settings.sortAz = it },
                { loadPlaylist(false) }),
            toggle("Cambiar de canal solo dentro del grupo", { settings.zapInGroup }, { settings.zapInGroup = it })
        )
    }

    private fun typeName(t: Int) = when (t) {
        Source.XTREAM -> "Xtream Codes"
        Source.STALKER -> "Portal Stalker"
        else -> "Lista M3U"
    }

    private fun listSettings(): List<SetItem> {
        val out = ArrayList<SetItem>()
        out.add(SetItem("Añadir lista", { "M3U, Xtream Codes o Portal Stalker" }) { addSource() })
        val active = store.active()?.id
        for (s in store.all()) {
            val name = if (s.id == active) "${s.name}  (en uso)" else s.name
            out.add(SetItem(name, { typeName(s.type) }) { sourceMenu(s) })
        }
        out.add(SetItem("Actualizar lista ahora", { "" }) {
            toast("Actualizando lista…")
            loadPlaylist(true)
        })
        out.add(toggle("Actualizar la lista al abrir la app", { settings.refreshOnOpen }, { settings.refreshOnOpen = it }))
        return out
    }

    private fun addSource() {
        Ui.choice(this, "Tipo de lista", listOf("Lista M3U", "Xtream Codes", "Portal Stalker"), -1) { t ->
            when (t) {
                0 -> Ui.form(this, "Lista M3U",
                    listOf("Nombre", "URL de la lista (http o https)"), listOf("Mi lista", ""), emptySet()
                ) { v -> saveSource(Source.M3U, v[0], v[1], "", "") }
                1 -> Ui.form(this, "Xtream Codes",
                    listOf("Nombre", "Servidor (http://host:puerto)", "Usuario", "Contraseña"),
                    listOf("Mi lista", "", "", ""), setOf(3)
                ) { v -> saveSource(Source.XTREAM, v[0], v[1], v[2], v[3]) }
                else -> Ui.form(this, "Portal Stalker",
                    listOf("Nombre", "URL del portal", "Dirección MAC (00:1A:79:xx:xx:xx)"),
                    listOf("Mi portal", "", ""), emptySet()
                ) { v -> saveSource(Source.STALKER, v[0], v[1], v[2], "") }
            }
        }
    }

    private fun saveSource(type: Int, name: String, a: String, b: String, c: String) {
        if (a.isBlank()) {
            toast("Falta la dirección")
            return
        }
        store.add(Source(store.newId(), type, name.ifBlank { "Lista" }, a.trim(), b, c))
        toast("Lista guardada")
        loadPlaylist(true)
        refreshSet()
    }

    private fun sourceMenu(s: Source) {
        Ui.choice(this, s.name, listOf("Usar esta lista", "Eliminar"), -1) { i ->
            if (i == 0) {
                store.setActive(s.id)
                loadPlaylist(true)
                refreshSet()
            } else {
                Ui.confirm(this, "Eliminar lista", "¿Eliminar \"${s.name}\"?") {
                    store.remove(s.id)
                    synchronized(stalker) { stalker.remove(s.id) }
                    loadPlaylist(false)
                    refreshSet()
                }
            }
        }
    }

    private fun epgSettings(): List<SetItem> {
        val hours = listOf(0, 6, 12, 24)
        val offs = (-12..12).toList()
        val last = settings.epgLastUpdate
        return listOf(
            SetItem("URL de la guía (XMLTV)", { if (settings.epgUrl.isBlank()) "Automática (la de la lista)" else settings.epgUrl }) {
                Ui.form(this, "Guía XMLTV (vacío = automática)", listOf("URL"), listOf(settings.epgUrl), emptySet()) { v ->
                    settings.epgUrl = v[0]
                    settings.epgLastUpdate = 0L
                    refreshEpg(true)
                    refreshSet()
                }
            },
            pick("Actualizar guía", listOf("Solo manual", "Cada 6 horas", "Cada 12 horas", "Cada 24 horas"),
                { hours.indexOf(settings.epgHours).let { if (it < 0) 2 else it } }, { settings.epgHours = hours[it] }),
            pick("Desfase horario de la guía", offs.map { if (it > 0) "+$it horas" else "$it horas" },
                { offs.indexOf(settings.epgOffsetHours) }, { settings.epgOffsetHours = offs[it] },
                { refreshGuide() }),
            SetItem("Actualizar guía ahora", {
                if (last == 0L) "Nunca actualizada"
                else "Última: " + SimpleDateFormat("d MMM HH:mm", Locale.getDefault()).format(Date(last))
            }) { refreshEpg(true) },
            SetItem("Borrar guía", { "" }) {
                epg.clear()
                settings.epgLastUpdate = 0L
                refreshGuide()
                refreshSet()
                toast("Guía borrada")
            }
        )
    }

    private fun applyTextScale() {
        val f = settings.textFactor()
        groupAdapter.factor = f
        catAdapter.factor = f
        groupAdapter.notifyDataSetChanged()
        catAdapter.notifyDataSetChanged()
        recentAdapter.notifyDataSetChanged()
        searchAdapter.notifyDataSetChanged()
        epgAdapter.notifyDataSetChanged()
        epgHeader.textFactor = f
        epgHeader.invalidate()
    }

    private fun appearanceSettings(): List<SetItem> = listOf(
        pick("Tamaño del texto", listOf("Pequeño", "Normal", "Grande"),
            { settings.textScale }, { settings.textScale = it }, { applyTextScale() }),
        toggle("Mostrar logos de canales", { settings.showLogos }, { settings.showLogos = it }, { applyTextScale() }),
        toggle("Mostrar números de canal", { settings.showNumbers }, { settings.showNumbers = it }, { applyTextScale() }),
        SetItem("Borrar caché de logos", { "" }) {
            logos.clearCache()
            toast("Caché de logos borrada")
        }
    )

    private fun playbackSettings(): List<SetItem> {
        val heights = listOf(720, 1080, 0)
        val timeouts = listOf(5, 10, 15, 20, 30)
        return listOf(
            pick("Tamaño del buffer", BufferPreset.labels(),
                { settings.bufferIndex }, { settings.bufferIndex = it }, { restartEngine() }),
            pick("Decodificador", listOf("Automático (hardware y, si falla, software)", "Solo hardware"),
                { settings.decoderMode }, { settings.decoderMode = it }, { restartEngine() }),
            pick("Relación de aspecto", listOf("Automática", "16:9", "4:3", "Estirar", "Zoom (pantalla completa)"),
                { settings.aspectMode }, { settings.aspectMode = it }, { applySurfaceLayout() }),
            pick("Resolución máxima", listOf("720p", "1080p", "Sin límite"),
                { heights.indexOf(settings.maxHeight).let { if (it < 0) 1 else it } },
                { settings.maxHeight = heights[it] }, { restartEngine() }),
            SetItem("User-Agent", { settings.userAgent }) { userAgentMenu() },
            pick("Tiempo de espera de red", timeouts.map { "$it segundos" },
                { timeouts.indexOf(settings.timeoutSec).let { if (it < 0) 1 else it } },
                { settings.timeoutSec = timeouts[it] }, { restartEngine() }),
            toggle("Reintentar automáticamente si se corta", { settings.autoRetry }, { settings.autoRetry = it },
                { restartEngine() })
        )
    }

    private fun userAgentMenu() {
        val opts = listOf("Zapix (por defecto)", "Navegador (Chrome)", "Escribir otro…")
        Ui.choice(this, "User-Agent", opts, -1) { i ->
            when (i) {
                0 -> settings.userAgent = Settings.DEFAULT_UA
                1 -> settings.userAgent = Settings.BROWSER_UA
                else -> {
                    Ui.form(this, "User-Agent", listOf("Texto"), listOf(settings.userAgent), emptySet()) { v ->
                        settings.userAgent = v[0].ifBlank { Settings.DEFAULT_UA }
                        restartEngine()
                        refreshSet()
                    }
                    return@choice
                }
            }
            restartEngine()
            refreshSet()
        }
    }

    private fun remoteSettings(): List<SetItem> = listOf(
        toggle("Invertir arriba y abajo al cambiar de canal", { settings.invertUpDown }, { settings.invertUpDown = it }),
        pick("Botón OK en pantalla completa", listOf("Mostrar información del canal", "Volver a la lista"),
            { settings.okInFull }, { settings.okInFull = it }),
        toggle("Izquierda y derecha cambian de canal", { settings.leftRight == 1 }, { settings.leftRight = if (it) 1 else 0 })
    )

    private fun groupNames(): List<String> = groupKeys.filterNotNull().filter { it != FAV }

    private fun parentalSettings(): List<SetItem> {
        val out = ArrayList<SetItem>()
        out.add(SetItem("PIN", { if (settings.pin.isEmpty()) "Sin PIN" else "Establecido" }) {
            if (settings.pin.isEmpty()) {
                newPin()
            } else {
                Ui.pin(this, "PIN actual") { p -> if (p == settings.pin) newPin() else toast("PIN incorrecto") }
            }
        })
        if (settings.pin.isNotEmpty()) {
            out.add(SetItem("Quitar PIN", { "" }) {
                Ui.pin(this, "PIN actual") { p ->
                    if (p == settings.pin) {
                        settings.pin = ""
                        settings.lockSettings = false
                        settings.setLockedGroups(emptySet())
                        refreshSet()
                    } else {
                        toast("PIN incorrecto")
                    }
                }
            })
        }
        out.add(SetItem("Grupos bloqueados", { "${settings.lockedGroups().size} grupos" }) {
            if (settings.pin.isEmpty()) {
                toast("Primero establece un PIN")
            } else {
                val names = groupNames()
                val locked = settings.lockedGroups()
                val checked = BooleanArray(names.size) { locked.contains(names[it]) }
                Ui.multi(this, "Grupos con PIN", names, checked) { c ->
                    settings.setLockedGroups(names.filterIndexed { i, _ -> c[i] }.toSet())
                    unlocked = false
                    applyGroup(listGroups.selectedItemPosition)
                    refreshSet()
                }
            }
        })
        out.add(toggle("Pedir PIN para entrar a Ajustes", { settings.lockSettings }, {
            if (settings.pin.isEmpty()) {
                toast("Primero establece un PIN")
            } else {
                settings.lockSettings = it
            }
        }))
        return out
    }

    private fun newPin() {
        Ui.pin(this, "Nuevo PIN (4 dígitos)") { p ->
            if (p.length == 4) {
                settings.pin = p
                toast("PIN guardado")
            } else {
                toast("El PIN debe tener 4 dígitos")
            }
            refreshSet()
        }
    }

    private fun otherSettings(): List<SetItem> = listOf(
        SetItem("Restablecer ajustes", { "Conserva tus listas, favoritos y PIN" }) {
            Ui.confirm(this, "Restablecer", "¿Volver todos los ajustes a su valor original?") {
                settings.resetAll()
                applyTextScale()
                restartEngine()
                loadPlaylist(false)
                refreshSet()
            }
        },
        SetItem("Sobre Zapix", { "Versión 1.0" }) {
            Ui.info(
                this, "Zapix",
                "Reproductor de listas M3U, Xtream Codes y Portal Stalker.\n" +
                    "Motor: AndroidX Media3 / ExoPlayer.\nTodos los ajustes están disponibles."
            )
        }
    )

    // =====================================================================
    // Control remoto
    // =====================================================================

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (mode == Mode.FULL) {
            val up = if (settings.invertUpDown) 1 else -1
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> zap(up)
                KeyEvent.KEYCODE_DPAD_DOWN -> zap(-up)
                KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> zap(1)
                KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> zap(-1)
                KeyEvent.KEYCODE_DPAD_LEFT -> if (settings.leftRight == 1) zap(-1) else return super.onKeyDown(keyCode, event)
                KeyEvent.KEYCODE_DPAD_RIGHT -> if (settings.leftRight == 1) zap(1) else return super.onKeyDown(keyCode, event)
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    longHandled = false
                    event.startTracking()
                }
                KeyEvent.KEYCODE_MENU -> exitFull()
                in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> typeDigit(keyCode - KeyEvent.KEYCODE_0)
                else -> return super.onKeyDown(keyCode, event)
            }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyLongPress(keyCode: Int, event: KeyEvent): Boolean {
        if (mode == Mode.FULL && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)) {
            longHandled = true
            current?.let { toggleFavorite(it) }
            return true
        }
        return super.onKeyLongPress(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (mode == Mode.FULL && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)) {
            if (!longHandled) {
                if (settings.okInFull == 1) exitFull() else current?.let { showInfo(it) }
            }
            longHandled = false
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (mode == Mode.FULL) {
            exitFull()
            return
        }
        val f = currentFocus
        if (f != null && !inSidebar(f)) {
            navs[tab].requestFocus()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    private fun inSidebar(v: View): Boolean {
        if (v === sidebar) return true
        var p = v.parent
        while (p != null) {
            if (p === sidebar) return true
            p = p.parent
        }
        return false
    }

    private companion object {
        const val TAB_SEARCH = 0
        const val TAB_HOME = 1
        const val TAB_TV = 2
        const val TAB_SET = 3
        const val FAV = "\u0001fav"
    }
}
